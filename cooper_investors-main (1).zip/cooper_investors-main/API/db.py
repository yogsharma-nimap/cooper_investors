from sqlalchemy.orm import relationship
from sqlalchemy import Boolean, Text, func
import pandas as pd
import logging
from datetime import datetime
from typing import Optional, Dict, Any, List
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Float, Date, Index, desc, func, ForeignKey, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from config import DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD, DATA_RETENTION_DAYS
from datetime import timedelta
import logging
import math

logger = logging.getLogger(__name__)
Base = declarative_base()

class JobStatus(Base):
    __tablename__ = 'job_status'
    id = Column(Integer, primary_key=True, autoincrement=True)
    job_date = Column(Date, nullable=False, default=lambda: datetime.now().date())
    req_start_date = Column(DateTime, nullable=False)
    req_end_date = Column(DateTime, nullable=False)
    is_pipeline_done = Column(Boolean, default=False)
    is_npa_done = Column(Boolean, default=False)
    status = Column(String(255), nullable=False)
    pipeline_start_time = Column(DateTime, nullable=True)
    pipeline_end_time = Column(DateTime, nullable=True)
    pipeline_time_taken = Column(Float, nullable=True, default=0.0)
    npa_start_time = Column(DateTime, nullable=True)
    npa_end_time = Column(DateTime, nullable=True)
    npa_time_taken = Column(Float, nullable=True, default=0.0)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, nullable=True)

    logs = relationship("Logs", back_populates="job_status")
    news_data = relationship("NewsData", back_populates="job_status")
    news_pulse_analytics = relationship("NewsPulseAnalytics", back_populates="job_status")
    news_data_history = relationship("NewsDataHistory", back_populates="job_status")
    news_pulse_analytics_history = relationship("NewsPulseAnalyticsHistory", back_populates="job_status")

class NewsData(Base):
    __tablename__ = 'news_data'
    id = Column(Integer, primary_key=True, autoincrement=True)
    job_id = Column(Integer, ForeignKey('job_status.id'), nullable=False, index=True)
    rp_entity_id = Column(String, index=True)
    entity_name = Column(String)
    timestamp = Column(DateTime, index=True)
    sentiment = Column(Float)
    relevance = Column(Integer)
    ess = Column(Float)
    created_at = Column(DateTime, default=datetime.now)

    __table_args__ = (
        Index('idx_nd_rp_entity_date', 'rp_entity_id', 'timestamp'),
        Index('idx_nd_job_id', 'job_id'),
    )

    job_status = relationship("JobStatus", back_populates="news_data")

class NewsDataHistory(Base):
    __tablename__ = 'news_data_history'
    id = Column(Integer, primary_key=True, autoincrement=True)
    job_id = Column(Integer, ForeignKey('job_status.id'), nullable=False, index=True)
    rp_entity_id = Column(String, index=True)
    entity_name = Column(String)
    timestamp = Column(DateTime, index=True)
    sentiment = Column(Float)
    relevance = Column(Integer)
    ess = Column(Float)
    created_at = Column(DateTime, default=datetime.now)

    __table_args__ = (
        Index('idx_ndh_rp_entity_date', 'rp_entity_id', 'timestamp'),
        Index('idx_ndh_job_id', 'job_id'),
    )

    job_status = relationship("JobStatus", back_populates="news_data_history")

class NewsPulseAnalytics(Base):
    __tablename__ = 'news_pulse_analytics'
    id = Column(Integer, primary_key=True, autoincrement=True)
    job_id = Column(Integer, ForeignKey('job_status.id'), nullable=False, index=True)
    entity_name = Column(String)
    rp_entity_id = Column(String(255), index=True)
    sedol = Column(String(50), index=True)
    days = Column(Integer)
    dates = Column(Date, index=True)
    psn_1 = Column(Integer); psn_2 = Column(Integer); psn_3 = Column(Integer); psn_4 = Column(Integer); psn_5 = Column(Integer)
    nsn_1 = Column(Integer); nsn_2 = Column(Integer); nsn_3 = Column(Integer); nsn_4 = Column(Integer); nsn_5 = Column(Integer)
    psn_unweighted = Column(Float)
    nsn_unweighted = Column(Float)
    news_pulse_unweighted = Column(Float)
    daily_weight = Column(Float)
    psn_timeweighted = Column(Float)
    nsn_timeweighted = Column(Float)
    news_pulse_timeweighted = Column(Float)

    __table_args__ = (
        Index('idx_npa_rp_entity_date', 'rp_entity_id', 'dates'),
        Index('idx_npa_job_id', 'job_id'),
    )

    job_status = relationship("JobStatus", back_populates="news_pulse_analytics")

class NewsPulseAnalyticsHistory(Base):
    __tablename__ = 'news_pulse_analytics_history'
    id = Column(Integer, primary_key=True, autoincrement=True)
    job_id = Column(Integer, ForeignKey('job_status.id'), nullable=False, index=True)
    entity_name = Column(String)
    rp_entity_id = Column(String(255), index=True)
    sedol = Column(String(50), index=True)
    days = Column(Integer)
    dates = Column(Date, index=True)
    psn_1 = Column(Integer); psn_2 = Column(Integer); psn_3 = Column(Integer); psn_4 = Column(Integer); psn_5 = Column(Integer)
    nsn_1 = Column(Integer); nsn_2 = Column(Integer); nsn_3 = Column(Integer); nsn_4 = Column(Integer); nsn_5 = Column(Integer)
    psn_unweighted = Column(Float)
    nsn_unweighted = Column(Float)
    news_pulse_unweighted = Column(Float)
    daily_weight = Column(Float)
    psn_timeweighted = Column(Float)
    nsn_timeweighted = Column(Float)
    news_pulse_timeweighted = Column(Float)

    __table_args__ = (
        Index('idx_npah_rp_entity_date', 'rp_entity_id', 'dates'),
        Index('idx_npah_job_id', 'job_id'),
        # Preventive Unique Constraint - ensures we never have the same date/stock double-ledgered per job
        Index('uix_npah_job_entity_sedol_date', 'job_id', 'rp_entity_id', 'sedol', 'dates', unique=True),
    )

    job_status = relationship("JobStatus", back_populates="news_pulse_analytics_history")

class Logs(Base):
    __tablename__ = 'logs'
    id = Column(Integer, primary_key=True, autoincrement=True)
    job_id = Column(Integer, ForeignKey('job_status.id'), nullable=False, index=True)
    log_type = Column(String(255), nullable=False)
    log_from = Column(String(255), nullable=False)
    log_title = Column(String(255), nullable=False)
    log_status = Column(Boolean, default=True)
    log_message = Column(Text, nullable=True)
    function_name = Column(String(255), nullable=True)
    class_name = Column(String(255), nullable=True)
    log_timestamp = Column(DateTime, index=True, default=datetime.now)

    job_status = relationship("JobStatus", back_populates="logs")

class RavenPackDatasetData(Base):
    __tablename__ = 'ravenpack_dataset_data'
    id = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id = Column(String(255), index=True)
    rp_entity_id = Column(String(255), index=True)
    stock_name = Column(String(255))
    country = Column(String(100))
    sector = Column(String(100))
    sentiment = Column(Float)
    relevance = Column(Integer)
    ess = Column(Float)
    event_date = Column(DateTime, index=True)
    created_at = Column(DateTime, default=datetime.now)
    sedol = Column(String(50), index=True)

class DatabaseOperation:
    """
    Handles robust, high-performance databasing for Postgres using SQLAlchemy ORM.
    """
    def __init__(self):
        self.engine_url = f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
        self.engine = create_engine(self.engine_url)
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        
    def create_table_if_not_exists(self):
        """
        Constructs the target tables and essential indexing using SQLAlchemy.
        """
        try:
            Base.metadata.create_all(self.engine)
            # Ensure sedol column exists gracefully if table was created previously
            with self.engine.begin() as conn:
                try:
                    conn.execute(text("ALTER TABLE ravenpack_dataset_data ADD COLUMN sedol VARCHAR(50);"))
                    conn.execute(text("CREATE INDEX ix_ravenpack_dataset_data_sedol ON ravenpack_dataset_data (sedol);"))
                except Exception:
                    # Column likely already exists
                    pass

            logger.info("Checked/Created tables successfully via ORM.")
        except Exception as e:
            logger.error(f"Error creating tables: {e}")
            raise

    def get_top_news(self, rp_entity_id: str, days: int = 90) -> Dict[str, List[Dict[str, Any]]]:
        """
        Retrieves top 5 positive and 5 negative news for a stock based on ESS.
        """
        try:
            session = self.SessionLocal()
            cutoff = datetime.now() - timedelta(days=days)
            
            # Positive news (Highest ESS)
            pos_news = session.query(NewsDataHistory)\
                .filter(NewsDataHistory.rp_entity_id == rp_entity_id)\
                .filter(NewsDataHistory.timestamp >= cutoff)\
                .filter(NewsDataHistory.ess > 0)\
                .order_by(desc(NewsDataHistory.ess))\
                .limit(5).all()
            
            # Negative news (Lowest ESS)
            neg_news = session.query(NewsDataHistory)\
                .filter(NewsDataHistory.rp_entity_id == rp_entity_id)\
                .filter(NewsDataHistory.timestamp >= cutoff)\
                .filter(NewsDataHistory.ess < 0)\
                .order_by(NewsDataHistory.ess)\
                .limit(5).all()
            
            def to_dict(rows):
                def _c(val):
                    if val is None or (isinstance(val, float) and (math.isnan(val) or math.isinf(val))):
                        return 0.0
                    return val
                return [{
                    "date": r.timestamp.strftime("%Y-%m-%d %H:%M"),
                    "ess": _c(r.ess),
                    "sentiment": _c(r.sentiment),
                    "relevance": r.relevance,
                    "entity_name": r.entity_name
                } for r in rows]

            return {
                "positive": to_dict(pos_news),
                "negative": to_dict(neg_news)
            }
        except Exception as e:
            logger.error(f"Error fetching top news: {e}")
            return {"positive": [], "negative": []}
        finally:
            if 'session' in locals():
                session.close()
            
    def insert_data_batch(self, df: pd.DataFrame, job_id: int, skip_cleanup: bool = False):
        """
        Inserts DataFrame efficiently using SQLAlchemy's core bulk insert.
        Now requires job_id for traceability.
        """
        if df.empty:
            logger.info("No data presented for batch insert.")
            return

        # entity_name is optional but should be persisted when available (mapped from ENTITY_NAME)
        required_cols = ['rp_entity_id', 'timestamp', 'sentiment', 'relevance', 'ess', 'job_id']
        optional_cols = ['entity_name']
        cols_to_insert = required_cols + [c for c in optional_cols if c in df.columns]

        missing_cols = [c for c in required_cols if c not in df.columns]
        if missing_cols:
            raise KeyError(f"DataFrame is missing required columns for inserting: {missing_cols}")

        # Sanitize DataFrame: Convert NaN/NaT to None for SQL compatibility
        clean_df = df[cols_to_insert].where(pd.notnull(df[cols_to_insert]), None)
        records = clean_df.to_dict(orient='records')
        
        try:
            with self.engine.begin() as conn:
                conn.execute(NewsData.__table__.insert(), records)
                conn.execute(NewsDataHistory.__table__.insert(), records)
            logger.info(f"Successfully ORM-bulk-inserted {len(records)} rows into 'news_data' and 'news_data_history'.")
            
            if not skip_cleanup:
                # Clean up old data from news_data table
                self.cleanup_active_data(NewsData, 'timestamp')
            
        except Exception as e:
            logger.error(f"Error during batch insert: {e}")
            raise
            
    def create_analytics_table_if_not_exists(self):
        """ Handled by create_table_if_not_exists in ORM setup """
        self.create_table_if_not_exists()

    def cleanup_active_data(self, model_class, date_col_name: str):
        """
        Deletes records from the active table that are older than DATA_RETENTION_DAYS.
        """
        try:
            session = self.SessionLocal()
            date_col = getattr(model_class, date_col_name)
            
            # Find the maximum date present in the table to baseline our window
            max_date = session.query(func.max(date_col)).scalar()
            
            if not max_date:
                logger.info(f"No records found in {model_class.__tablename__} for cleanup.")
                return

            # Calculate cutoff relative to the latest record
            cutoff_date = max_date - timedelta(days=DATA_RETENTION_DAYS)
            
            if model_class == NewsPulseAnalytics and hasattr(cutoff_date, 'date'):
                cutoff_date = cutoff_date.date()
                
            # Perform the cleanup
            deleted_count = session.query(model_class).filter(date_col < cutoff_date).delete(synchronize_session=False)
            session.commit()
            
            if deleted_count > 0:
                logger.info(f"Cleanup Successful - Table: {model_class.__tablename__} | Max Record: {max_date} | Cutoff: {cutoff_date} | Records Removed: {deleted_count}")
            else:
                logger.info(f"Cleanup skipped for {model_class.__tablename__} - No records older than {cutoff_date}")
            
        except Exception as e:
            logger.error(f"Error during data cleanup for {model_class.__tablename__}: {e}")
            if 'session' in locals():
                session.rollback()
        finally:
            if 'session' in locals():
                session.close()

    def insert_analytics_batch(self, df: pd.DataFrame, job_id: int, skip_cleanup: bool = False):
        """ Pushes News Pulse calculation dataframe straight to DB via ORM """
        if df.empty:
            return
            
        columns_mapping = {
            'RP_ENTITY_ID': 'rp_entity_id', 'SEDOL': 'sedol', 'Days': 'days', 'Dates': 'dates',
            'PSN 1': 'psn_1', 'PSN 2': 'psn_2', 'PSN 3': 'psn_3', 'PSN 4': 'psn_4', 'PSN 5': 'psn_5',
            'NSN 1': 'nsn_1', 'NSN 2': 'nsn_2', 'NSN 3': 'nsn_3', 'NSN 4': 'nsn_4', 'NSN 5': 'nsn_5',
            'PSN (Unweighted)': 'psn_unweighted', 'NSN (Unweighted)': 'nsn_unweighted',
            'News Pulse (Unweighted)': 'news_pulse_unweighted', 'Daily Weight': 'daily_weight',
            'PSN (TimeWeighted)': 'psn_timeweighted', 'NSN (TimeWeighted)': 'nsn_timeweighted',
            'News Pulse (TimeWeighted)': 'news_pulse_timeweighted', 'job_id': 'job_id'
        }
        
        insert_df = df.rename(columns=columns_mapping)
        insert_df['dates'] = pd.to_datetime(insert_df['dates']).dt.date
        
        try:
            session = self.SessionLocal()
            # Targeted Cleanup: Remove existing results for this specific JOB + ENTITY + SEDOL
            if 'rp_entity_id' in insert_df.columns and not insert_df['rp_entity_id'].empty:
                target_ids = insert_df['rp_entity_id'].unique().tolist()
                target_sedols = insert_df['sedol'].unique().tolist() if 'sedol' in insert_df.columns else []
                
                # Clear from Active Table
                active_query = session.query(NewsPulseAnalytics).filter(NewsPulseAnalytics.rp_entity_id.in_(target_ids))
                if target_sedols:
                    active_query = active_query.filter(NewsPulseAnalytics.sedol.in_(target_sedols))
                active_query.delete(synchronize_session=False)
                
                # Clear from History Table for this specific job to avoid ledger duplication
                hist_query = session.query(NewsPulseAnalyticsHistory).filter(
                    NewsPulseAnalyticsHistory.job_id == job_id,
                    NewsPulseAnalyticsHistory.rp_entity_id.in_(target_ids)
                )
                if target_sedols:
                    hist_query = hist_query.filter(NewsPulseAnalyticsHistory.sedol.in_(target_sedols))
                hist_query.delete(synchronize_session=False)
            
            # Step 2: Batch Insert into both Active and History tables
            clean_insert_df = insert_df[list(columns_mapping.values())].where(pd.notnull(insert_df), None)
            records = clean_insert_df.to_dict(orient='records')
            session.bulk_insert_mappings(NewsPulseAnalytics, records)
            session.bulk_insert_mappings(NewsPulseAnalyticsHistory, records)
            session.commit()
            logger.info(f"Successfully batch-inserted {len(records)} analytical rows into 'news_pulse_analytics' and 'news_pulse_analytics_history'.")
            
            if not skip_cleanup:
                # Step 3: Clean up old data from news_pulse_analytics table
                self.cleanup_active_data(NewsPulseAnalytics, 'dates')
            
        except Exception as e:
            logger.error(f"Error during analytics batch insert: {e}")
            if 'session' in locals():
                session.rollback()
            raise
        finally:
            if 'session' in locals():
                session.close()

    def fetch_historical_data(self, rp_entity_id: str, start_date: str, end_date: str) -> pd.DataFrame:
        """
        Retrieves all inserted historical raw datasets from Postgres to ensure 
        we aggregate News Pulse analytics over the full continuous 12-months of data.
        """
        try:
            session = self.SessionLocal()
            query = session.query(NewsDataHistory.timestamp, NewsDataHistory.sentiment, NewsDataHistory.relevance, NewsDataHistory.ess)\
                           .filter(NewsDataHistory.rp_entity_id == rp_entity_id)\
                           .filter(NewsDataHistory.timestamp >= start_date)\
                           .filter(NewsDataHistory.timestamp <= end_date)\
                           .filter(NewsDataHistory.relevance >= 80)
            
            df = pd.read_sql(query.statement, session.bind)
            return df
        except Exception as e:
            logger.error(f"Error querying Postgres via ORM: {e}")
            raise
        finally:
            if 'session' in locals():
                session.close()

    def get_max_timestamp(self, rp_entity_id: str) -> Optional[datetime]:
        """
        Retrieves the maximum existing timestamp for a specific entity in the database (from history).
        """
        try:
            session = self.SessionLocal()
            max_ts = session.query(func.max(NewsDataHistory.timestamp))\
                            .filter(NewsDataHistory.rp_entity_id == rp_entity_id)\
                            .scalar()
            return max_ts
        except Exception as e:
            logger.error(f"Error fetching max timestamp for {rp_entity_id}: {e}")
            return None
        finally:
            if 'session' in locals():
                session.close()

    def get_all_records_by_entity_id(self, rp_entity_id: str) -> List[Dict[str, Any]]:
        """
        Retrieves all records for a given entity ID from the news_data_history table.
        """
        try:
            session = self.SessionLocal()
            records = session.query(NewsDataHistory).filter(NewsDataHistory.rp_entity_id == rp_entity_id)\
                             .order_by(desc(NewsDataHistory.timestamp)).all()
            
            if not records:
                return []
            
            results = []
            for record in records:
                # Convert Model instance to dict
                res = {c.name: getattr(record, c.name) for c in record.__table__.columns}
                
                cleaned_res = {}
                for key, value in res.items():
                    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
                        cleaned_res[key] = None
                    else:
                        cleaned_res[key] = value
                results.append(cleaned_res)
            return results
        except Exception as e:
            logger.error(f"Error fetching all records for {rp_entity_id}: {e}")
            return []
        finally:
            if 'session' in locals():
                session.close()

    def get_record_by_id(self, rp_entity_id: str) -> Optional[Dict[str, Any]]:
        """
        Retrieves the latest single record by its entity ID using SQLAlchemy ORM.
        """
        all_records = self.get_all_records_by_entity_id(rp_entity_id)
        return all_records[0] if all_records else None

    def log_to_db(self, job_id: int, log_type: str, log_from: str, log_title: str, log_message: str, log_status: bool = True, function_name: str = None, class_name: str = None):
        """
        Inserts a log entry into the logs table.
        """
        logger.info(f"[{log_type}] {log_title}: {log_message}")
        
        if job_id <= 0:
            return

        try:
            session = self.SessionLocal()
            new_log = Logs(
                job_id=job_id,
                log_type=log_type,
                log_from=log_from,
                log_title=log_title,
                log_message=log_message,
                log_status=log_status,
                function_name=function_name,
                class_name=class_name,
                log_timestamp=datetime.now()
            )
            session.add(new_log)
            session.commit()
        except Exception as e:
            logger.error(f"Error inserting log into DB: {e}")
            if 'session' in locals():
                session.rollback()
        finally:
            if 'session' in locals():
                session.close()

    def get_next_job_id(self, start_date: datetime, end_date: datetime) -> int:
        """
        Retrieves the next corn job ID from the corn_job_status table by inserting a pending record.
        Uses database level autoincrement to ensure thread-safety and uniqueness.
        """
        session = None
        try:
            session = self.SessionLocal()
            new_corn_job = JobStatus(
                job_date = datetime.now().date(),
                req_start_date = start_date,
                req_end_date = end_date,
                status = "pending",
                pipeline_start_time = datetime.now(),
                updated_at = datetime.now(),
            )
            session.add(new_corn_job)
            session.commit()
            session.refresh(new_corn_job)
            return new_corn_job.id
        except Exception as e:
            logger.error(f"Error creating next corn job: {e}")
            if session:
                session.rollback()
            raise
        finally:
            if session:
                session.close()

    def update_npa_start_time(self, job_id: int):
        """
        Updates the npa_start_time of a corn job in the corn_job_status table.
        """
        try:
            session = self.SessionLocal()
            corn_job = session.query(JobStatus).filter(JobStatus.id == job_id).first()
            if corn_job:
                corn_job.npa_start_time = datetime.now()
                corn_job.updated_at = datetime.now()
                session.commit()
        except Exception as e:
            logger.error(f"Error updating NPA start time: {e}")
            if 'session' in locals():
                session.rollback()
        finally:
            if 'session' in locals():
                session.close()

    def update_pipeline_status(self, job_id: int, status: str, is_pipeline_done: bool = False):
        """
        Updates the status of a corn job in the corn_job_status table.
        """
        try:
            session = self.SessionLocal()
            corn_job = session.query(JobStatus).filter(JobStatus.id == job_id).first()
            if corn_job:
                corn_job.status = status
                if is_pipeline_done:
                    corn_job.is_pipeline_done = True
                    corn_job.pipeline_end_time = datetime.now()
                    if corn_job.pipeline_start_time:
                        corn_job.pipeline_time_taken = (corn_job.pipeline_end_time - corn_job.pipeline_start_time).total_seconds()
                        corn_job.updated_at = datetime.now()
                    else:
                        corn_job.pipeline_time_taken = 0.0
                session.commit()
        except Exception as e:
            logger.error(f"Error updating pipeline job status: {e}")
            if 'session' in locals():
                session.rollback()
        finally:
            if 'session' in locals():
                session.close()

    def update_npa_status(self, job_id: int, status: str, is_npa_done: bool = False):
        """
        Updates the status of a corn job in the corn_job_status table.
        """
        try:
            session = self.SessionLocal()
            corn_job = session.query(JobStatus).filter(JobStatus.id == job_id).first()
            if corn_job:
                corn_job.status = status
                if is_npa_done:
                    corn_job.is_npa_done = True
                    corn_job.npa_end_time = datetime.now()
                    if corn_job.npa_start_time:
                        corn_job.npa_time_taken = (corn_job.npa_end_time - corn_job.npa_start_time).total_seconds()
                        corn_job.updated_at = datetime.now()
                    else:
                        corn_job.npa_time_taken = 0.0
                session.commit()
        except Exception as e:
            logger.error(f"Error updating NPA job status: {e}")
            if 'session' in locals():
                session.rollback()
        finally:
            if 'session' in locals():
                session.close()
    
    def get_latest_pipeline_details(self):
        try:
            session = self.SessionLocal()
            pipeline_details = session.query(JobStatus).order_by(desc(JobStatus.id)).first()
            return pipeline_details
        except Exception as e:
            logger.error(f"Error fetching pipeline details: {e}")
            return []
        finally:
            if 'session' in locals():
                session.close()

    def get_pipeline_details(self, id: int = None):
        """
        Retrieves the pipeline details from the corn_job_status table.
        """
        try:
            session = self.SessionLocal()
            if id:
                pipeline_details = session.query(JobStatus).filter(JobStatus.id == id).first()
            else:
                pipeline_details = session.query(JobStatus).all()
            return pipeline_details
        except Exception as e:
            logger.error(f"Error fetching pipeline details: {e}")
            return []
        finally:
            if 'session' in locals():
                session.close()

    def get_portfolio_sentiment(self, target_sedols: List[str] = None) -> List[Dict[str, Any]]:
        """
        Returns the latest News Pulse (TimeWeighted) per SEDOL/entity
        from the most recent completed NPA job, used for treemap rendering.
        """
        try:
            session = self.SessionLocal()

            # Step 1: Latest completed NPA job
            latest_job = session.query(JobStatus)\
                .filter(JobStatus.is_npa_done == True)\
                .order_by(desc(JobStatus.id))\
                .first()

            if not latest_job:
                logger.info("No completed NPA job found for portfolio sentiment.")
                return []

            job_id = latest_job.id
            logger.info(f"Fetching portfolio sentiment for job_id={job_id}")

            # Step 2: Subquery — max date per SEDOL + RP_ENTITY_ID for this job
            subquery = session.query(
                NewsPulseAnalytics.sedol,
                NewsPulseAnalytics.rp_entity_id,
                func.max(NewsPulseAnalytics.dates).label("max_date")
            ).filter(
                NewsPulseAnalytics.job_id == job_id
            ).group_by(
                NewsPulseAnalytics.sedol,
                NewsPulseAnalytics.rp_entity_id
            ).subquery()

            name_query = session.query(
                NewsDataHistory.rp_entity_id,
                NewsDataHistory.entity_name
            ).distinct(NewsDataHistory.rp_entity_id)\
             .subquery()

            # Step 3: Join back to get the full row for each latest date
            rows = session.query(NewsPulseAnalytics, name_query.c.entity_name)\
                .join(
                    subquery,
                    (NewsPulseAnalytics.sedol == subquery.c.sedol) &
                    (NewsPulseAnalytics.rp_entity_id == subquery.c.rp_entity_id) &
                    (NewsPulseAnalytics.dates == subquery.c.max_date)
                )\
                .outerjoin(   # safer join
                    name_query,
                    NewsPulseAnalytics.rp_entity_id == name_query.c.rp_entity_id
                )\
                .filter(NewsPulseAnalytics.job_id == job_id)\
                .all()
            
            result = []
            for r, entity_name in rows:
                if target_sedols and r.sedol not in target_sedols:
                    continue

                pulse_tw = r.news_pulse_timeweighted
                pulse_uw = r.news_pulse_unweighted

                # Sanitize any NaN/Inf that may have crept in from calculations
                if pulse_tw is None or (isinstance(pulse_tw, float) and (math.isnan(pulse_tw) or math.isinf(pulse_tw))):
                    pulse_tw = 0.0
                if pulse_uw is None or (isinstance(pulse_uw, float) and (math.isnan(pulse_uw) or math.isinf(pulse_uw))):
                    pulse_uw = 0.0

                result.append({
                    "sedol": r.sedol,
                    "entity_name": entity_name,
                    "rp_entity_id": r.rp_entity_id,
                    "news_pulse_timeweighted": round(pulse_tw, 2),
                    "news_pulse_unweighted": round(pulse_uw, 2),
                    "psn_timeweighted": r.psn_timeweighted or 0.0,
                    "nsn_timeweighted": r.nsn_timeweighted or 0.0,
                    "latest_date": str(r.dates),
                    "job_id": job_id,
                })

            logger.info(f"Portfolio sentiment: returned {len(result)} stocks for job_id={job_id}")
            return result

        except Exception as e:
            logger.error(f"Error fetching portfolio sentiment: {e}")
            return []
        finally:
            if 'session' in locals():
                session.close()

    def insert_rp_dataset_data(self, dataset_id: str, records: List[Dict[str, Any]]):
        """
        Inserts data fetched from a RavenPack dataset into the ravenpack_dataset_data table.
        """
        try:
            session = self.SessionLocal()
            
            # Map RavenPack record fields to our model fields
            to_insert = []
            for rec in records:
                # RavenPack JSON keys can be upper or lower case depending on the product
                raw_ts = rec.get("TIMESTAMP_UTC") or rec.get("timestamp_utc")
                
                event_date = None
                if raw_ts:
                    parsed_ts = pd.to_datetime(raw_ts)
                    if pd.notnull(parsed_ts):
                        event_date = parsed_ts.to_pydatetime()

                _MISSING = object()

                def _first_present(d, *keys):
                    """Return the value of the first key present in dict d (even if 0/False)."""
                    for k in keys:
                        v = d.get(k, _MISSING)
                        if v is not _MISSING:
                            return v
                    return None

                def _safe_float(val):
                    try:
                        f = float(val)
                        return None if (f != f) else f   # NaN check without import
                    except (TypeError, ValueError):
                        return None

                def _safe_int(val):
                    try:
                        return int(float(val)) if val is not None else None
                    except (TypeError, ValueError):
                        return None
               
                raw_ess = _first_present(rec, "ESS", "ess")
                if raw_ess is None:
                    raw_ess = _first_present(rec, "EVENT_SENTIMENT_SCORE", "event_sentiment_score",
                                              "SENTIMENT", "sentiment")

                raw_sentiment = _first_present(rec, "EVENT_SENTIMENT_SCORE", "event_sentiment_score",
                                               "SENTIMENT", "sentiment")

                to_insert.append({
                    "dataset_id": dataset_id,
                    "rp_entity_id": _first_present(rec, "RP_ENTITY_ID", "rp_entity_id"),
                    "sedol": _first_present(rec, "SEDOL", "sedol"),
                    "stock_name": _first_present(rec, "ENTITY_NAME", "entity_name"),
                    "country": _first_present(rec, "COUNTRY", "country", "country_code"),
                    "sector": _first_present(rec, "SECTOR", "sector"),
                    "sentiment": _safe_float(raw_sentiment),
                    "relevance": _safe_int(_first_present(rec, "RELEVANCE", "relevance")),
                    "ess": _safe_float(raw_ess),
                    "event_date": event_date,
                })
            
            if to_insert:
                # Clear old data for this dataset to maintain fresh "highlight"
                session.query(RavenPackDatasetData).filter(RavenPackDatasetData.dataset_id == dataset_id).delete()
                session.bulk_insert_mappings(RavenPackDatasetData, to_insert)
                session.commit()
                logger.info(f"Successfully inserted {len(to_insert)} records for dataset {dataset_id}")
        except Exception as e:
            logger.error(f"Error inserting dataset data: {e}")
            if 'session' in locals():
                session.rollback()
            raise
        finally:
            if 'session' in locals():
                session.close()

    def get_rp_dataset_data(self, dataset_id: str) -> List[Dict[str, Any]]:
        """
        Retrieves stored data for a specific RavenPack dataset.
        """
        try:
            session = self.SessionLocal()
            rows = session.query(RavenPackDatasetData).filter(RavenPackDatasetData.dataset_id == dataset_id).all()
            
            results = []
            for r in rows:
                def _clean_float(val):
                    if val is None:
                        return None
                    if isinstance(val, float) and (math.isnan(val) or math.isinf(val)):
                        return None
                    return val

                results.append({
                    "id": r.id,
                    "dataset_id": r.dataset_id,
                    "rp_entity_id": r.rp_entity_id,
                    "sedol": r.sedol,
                    "stock_name": r.stock_name,
                    "country": r.country,
                    "sector": r.sector,
                    "sentiment": _clean_float(r.sentiment),
                    "relevance": r.relevance,
                    "ess": _clean_float(r.ess),
                    "event_date": r.event_date.isoformat() if r.event_date else None,
                })
            return results
        except Exception as e:
            logger.error(f"Error fetching dataset data: {e}")
            return []
        finally:
            if 'session' in locals():
                session.close()

    def get_sentiment_history(self, rp_entity_id: str) -> List[Dict[str, Any]]:
        """
        Retrieves historical sentiment trend for a specific entity from NewsPulseAnalyticsHistory.
        """
        try:
            session = self.SessionLocal()
            # We want historical data for this entity, sorted by date
            records = session.query(NewsPulseAnalyticsHistory)\
                             .filter(NewsPulseAnalyticsHistory.rp_entity_id == rp_entity_id)\
                             .order_by(NewsPulseAnalyticsHistory.dates)\
                             .all()
            
            results = []
            for r in records:
                # Sanitize
                sentiment_tw = r.news_pulse_timeweighted
                if sentiment_tw is None or (isinstance(sentiment_tw, float) and (math.isnan(sentiment_tw) or math.isinf(sentiment_tw))):
                    sentiment_tw = 0.0

                results.append({
                    "date": str(r.dates),
                    "sentiment": round(sentiment_tw, 2),
                })
            return results
        except Exception as e:
            logger.error(f"Error fetching sentiment history for {rp_entity_id}: {e}")
            return []
        finally:
            if 'session' in locals():
                session.close()

    def _ensure_dataset_mapping(self):
        """
        Populates the _rp_dataset_mapping cache from RavenPack API if not already present.
        """
        if hasattr(self, '_rp_dataset_mapping') and self._rp_dataset_mapping:
            return

        try:
            from fetch_ravenpack import RavenPackClient
            rp_client = RavenPackClient()
            all_ds = rp_client.list_datasets()
            self._rp_dataset_mapping = {}
            for ds in all_ds:
                ds_id = ds.get('uuid') or ds.get('id') or ds.get('dataset_id')
                ds_name = ds.get('name') or ds.get('dataset_name') or ds_id
                if ds_id:
                    self._rp_dataset_mapping[ds_id] = ds_name
        except Exception as map_err:
            logger.error(f"Failed to fetch dataset mapping: {map_err}")
            self._rp_dataset_mapping = {}

    def get_shorts_data(self, dataset_filter: str = None, exclude_sedols: List[str] = None, start_date: str = None, end_date: str = None, adtv_min: float = 10.0) -> List[Dict[str, Any]]:
        """
        Retrieves data for the Shorts tab.
        Filters for datasets starting with "Shorts_", extracts the screen name,
        and ensures unique stocks per screen name.
        Also filters by ADTV (Average Daily Trading Volume).
        """
        try:
            session = self.SessionLocal()
            self._ensure_dataset_mapping()
            
            # 1. Get the latest record for each entity in the dataset table
            subq = session.query(
                RavenPackDatasetData.rp_entity_id,
                RavenPackDatasetData.dataset_id,
                func.max(RavenPackDatasetData.event_date).label('max_date')
            )
            if dataset_filter and dataset_filter != "All Data-Sets":
                subq = subq.filter(RavenPackDatasetData.dataset_id == dataset_filter)
            
            if start_date:
                subq = subq.filter(RavenPackDatasetData.event_date >= start_date)
            if end_date:
                subq = subq.filter(RavenPackDatasetData.event_date <= end_date)
                
            subq = subq.group_by(RavenPackDatasetData.rp_entity_id, RavenPackDatasetData.dataset_id).subquery()
            
            dataset_records = session.query(RavenPackDatasetData).join(
                subq, 
                (RavenPackDatasetData.rp_entity_id == subq.c.rp_entity_id) & 
                (RavenPackDatasetData.dataset_id == subq.c.dataset_id) &
                (RavenPackDatasetData.event_date == subq.c.max_date)
            )
            
            if dataset_filter and dataset_filter != "All Data-Sets":
                dataset_records = dataset_records.filter(RavenPackDatasetData.dataset_id == dataset_filter)
                
            dataset_records = dataset_records.all()
            if exclude_sedols:
                dataset_records = [r for r in dataset_records if r.sedol not in exclude_sedols]
            
            # 2. Build the output list
            results = []
            seen = set()
            
            for rec in dataset_records:
                sedol = rec.sedol or "N/A"
                identifier = sedol if sedol != "N/A" else rec.rp_entity_id

                raw_screen_name = self._rp_dataset_mapping.get(rec.dataset_id)
                
                # Filter for "Shorts_" datasets only
                if not raw_screen_name or not raw_screen_name.startswith("Shorts_"):
                    continue
                
                # Extract screen name (e.g., "Shorts_InsiderSelling" -> "InsiderSelling")
                screen_name = raw_screen_name.split("Shorts_", 1)[1]

                # Grouping: Only show unique stocks per Screen Name
                key = (identifier, screen_name)
                if key in seen:
                    continue
                seen.add(key)

                # --- ADTV MOCKING ---
                # As requested, keep static/mock for now. 
                # We'll use a deterministic mock based on the identifier to keep it consistent
                import hashlib
                mock_seed = int(hashlib.md5(identifier.encode()).hexdigest(), 16)
                adtv_val = (mock_seed % 100) + 1  # Random value between 1 and 100
                
                if adtv_val < adtv_min:
                    continue

                # Latest Pulse
                latest_pulse = None
                pulse_query = session.query(NewsPulseAnalytics)
                if end_date:
                    try:
                        parsed_end_date = pd.to_datetime(end_date).date()
                        pulse_query = pulse_query.filter(NewsPulseAnalytics.dates <= parsed_end_date)
                    except Exception:
                        pass
                
                if sedol and sedol != "N/A":
                    latest_pulse = pulse_query\
                        .filter(NewsPulseAnalytics.sedol == sedol)\
                        .order_by(desc(NewsPulseAnalytics.dates))\
                        .first()
                if not latest_pulse:
                    latest_pulse = pulse_query\
                        .filter(NewsPulseAnalytics.rp_entity_id == rec.rp_entity_id)\
                        .order_by(desc(NewsPulseAnalytics.dates))\
                        .first()

                pulse_val = latest_pulse.news_pulse_timeweighted if latest_pulse else 0.0

                # Change Calculation (Previous Day)
                change = 0.0
                if latest_pulse:
                    one_day_ago = latest_pulse.dates - timedelta(days=1)
                    past_pulse = session.query(NewsPulseAnalyticsHistory)\
                        .filter(NewsPulseAnalyticsHistory.rp_entity_id == rec.rp_entity_id)\
                        .filter(NewsPulseAnalyticsHistory.dates <= one_day_ago)\
                        .order_by(desc(NewsPulseAnalyticsHistory.dates))\
                        .first()
                    past_val = past_pulse.news_pulse_timeweighted if past_pulse else pulse_val
                    change = pulse_val - past_val

                # Sanitization
                if pulse_val is None or (isinstance(pulse_val, float) and math.isnan(pulse_val)): pulse_val = 0.0
                if change is None or (isinstance(change, float) and math.isnan(change)): change = 0.0

                rec_sentiment = rec.sentiment
                rec_ess = rec.ess
                if rec_sentiment is None or (isinstance(rec_sentiment, float) and (math.isnan(rec_sentiment) or math.isinf(rec_sentiment))):
                    rec_sentiment = None
                if rec_ess is None or (isinstance(rec_ess, float) and (math.isnan(rec_ess) or math.isinf(rec_ess))):
                    rec_ess = None

                results.append({
                    "sedol": sedol,
                    "rp_entity_id": rec.rp_entity_id,
                    "company": rec.stock_name or "Unknown",
                    "country": rec.country or "N/A",
                    "sector": rec.sector or "N/A",
                    "screen": screen_name,
                    "sentiment": rec_sentiment,
                    "relevance": rec.relevance,
                    "ess": rec_ess,
                    "pulse": round(pulse_val, 2),
                    "change": round(change, 2),
                    "adtv": adtv_val
                })
                
            return results
        except Exception as e:
            logger.error(f"Error fetching shorts data: {e}")
            return []
        finally:
            if 'session' in locals():
                session.close()

    def get_added_datasets(self) -> List[Dict[str, Any]]:
        """
        Retrieves all unique dataset IDs that have been added to the database and start with "Shorts_".
        """
        try:
            session = self.SessionLocal()
            self._ensure_dataset_mapping()
            
            distinct_ids = session.query(RavenPackDatasetData.dataset_id).distinct().all()
            
            results = [{
                "dataset_id": "All Data-Sets",
                "dataset_name": "All Data-Sets"
            }]
            
            for (ds_id,) in distinct_ids:
                if not ds_id:
                    continue
                
                raw_screen_name = self._rp_dataset_mapping.get(ds_id)
                if not raw_screen_name:
                    continue
                
                if raw_screen_name.startswith("Shorts_"):
                    screen_name = raw_screen_name.split("Shorts_", 1)[1]
                    prefix = "Shorts"
                elif raw_screen_name.startswith("Themes_"):
                    screen_name = raw_screen_name.split("Themes_", 1)[1]
                    prefix = "Themes"
                else:
                    continue
                    
                results.append({
                    "dataset_id": ds_id,
                    "dataset_name": screen_name,
                    "type": prefix
                })
            
            return results
        except Exception as e:
            logger.error(f"Error fetching added datasets: {e}")
            return []
        finally:
            if 'session' in locals():
                session.close()

    def get_shorts_sedols(self) -> List[str]:
        """
        Retrieves all unique SEDOLs from the RavenPackDatasetData table.
        """
        try:
            session = self.SessionLocal()
            distinct_sedols = session.query(RavenPackDatasetData.sedol).distinct().all()
            return [sedol[0] for sedol in distinct_sedols if sedol[0]]
        except Exception as e:
            logger.error(f"Error fetching short dataset SEDOLs: {e}")
            return []
        finally:
            if 'session' in locals():
                session.close()

    def get_themes_data(self, dataset_filter: str = None) -> List[Dict[str, Any]]:
        """
        Retrieves aggregated data for themes.
        Filters for datasets starting with "Themes_", calculates average pulse.
        """
        try:
            session = self.SessionLocal()
            self._ensure_dataset_mapping()
            
            # 1. Get all theme datasets
            distinct_datasets = session.query(RavenPackDatasetData.dataset_id).distinct().all()
            theme_datasets = []
            for (ds_id,) in distinct_datasets:
                name = self._rp_dataset_mapping.get(ds_id)
                if name and name.startswith("Themes_"):
                    if not dataset_filter or dataset_filter == "All Data-Sets" or dataset_filter == ds_id:
                        theme_datasets.append({"id": ds_id, "name": name.split("Themes_", 1)[1]})
            
            results = []
            for theme in theme_datasets:
                # Get entities for this theme
                entities = session.query(RavenPackDatasetData.rp_entity_id).filter(RavenPackDatasetData.dataset_id == theme["id"]).distinct().all()
                entity_ids = [e[0] for e in entities if e[0]]
                
                if not entity_ids:
                    continue

                # Get latest average pulse for these entities
                latest_job = session.query(JobStatus).filter(JobStatus.is_npa_done == True).order_by(desc(JobStatus.id)).first()
                if not latest_job:
                    continue

                # Find max date available for these entities in this job
                max_date_subq = session.query(func.max(NewsPulseAnalytics.dates)).filter(
                    NewsPulseAnalytics.job_id == latest_job.id,
                    NewsPulseAnalytics.rp_entity_id.in_(entity_ids)
                ).scalar()

                if not max_date_subq:
                    continue

                # Average pulse on that max date
                avg_pulse = session.query(func.avg(NewsPulseAnalytics.news_pulse_timeweighted)).filter(
                    NewsPulseAnalytics.job_id == latest_job.id,
                    NewsPulseAnalytics.rp_entity_id.in_(entity_ids),
                    NewsPulseAnalytics.dates == max_date_subq
                ).scalar()

                # Previous day average for change calculation
                prev_date = max_date_subq - timedelta(days=1)
                prev_avg_pulse = session.query(func.avg(NewsPulseAnalyticsHistory.news_pulse_timeweighted)).filter(
                    NewsPulseAnalyticsHistory.rp_entity_id.in_(entity_ids),
                    NewsPulseAnalyticsHistory.dates == prev_date
                ).scalar()

                pulse_val = float(avg_pulse) if avg_pulse is not None else 0.0
                prev_pulse_val = float(prev_avg_pulse) if prev_avg_pulse is not None else pulse_val
                change = pulse_val - prev_pulse_val

                results.append({
                    "theme_id": theme["id"],
                    "theme_name": theme["name"],
                    "pulse": round(pulse_val, 2),
                    "change": round(change, 2),
                    "stock_count": len(entity_ids),
                    "latest_date": str(max_date_subq)
                })
            
            return results
        except Exception as e:
            logger.error(f"Error fetching themes data: {e}")
            return []
        finally:
            if 'session' in locals():
                session.close()

    def get_theme_sentiment_history(self, dataset_id: str, days: int = 365) -> List[Dict[str, Any]]:
        """
        Retrieves aggregated historical sentiment trend for a specific theme.
        """
        try:
            session = self.SessionLocal()
            
            # 1. Get entities for this theme
            entities = session.query(RavenPackDatasetData.rp_entity_id).filter(RavenPackDatasetData.dataset_id == dataset_id).distinct().all()
            entity_ids = [e[0] for e in entities if e[0]]
            
            if not entity_ids:
                return []

            # 2. Query historical table, grouped by date, averaged across entities
            cutoff_date = datetime.now().date() - timedelta(days=days)

            history = session.query(
                NewsPulseAnalyticsHistory.dates,
                func.avg(NewsPulseAnalyticsHistory.news_pulse_timeweighted).label("avg_pulse")
            ).filter(
                NewsPulseAnalyticsHistory.rp_entity_id.in_(entity_ids),
                NewsPulseAnalyticsHistory.dates >= cutoff_date
            ).group_by(
                NewsPulseAnalyticsHistory.dates
            ).order_by(
                NewsPulseAnalyticsHistory.dates
            ).all()

            results = []
            for row in history:
                results.append({
                    "date": str(row.dates),
                    "news_pulse": round(float(row.avg_pulse), 2) if row.avg_pulse is not None else 0.0
                })
            return results
        except Exception as e:
            logger.error(f"Error fetching theme sentiment history: {e}")
            return []
        finally:
            if 'session' in locals():
                session.close()