from utils import log_to_db
import logging
import os
from datetime import datetime
from dateutil.relativedelta import relativedelta
import pandas as pd
import time
from fastapi import FastAPI, status
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from mapping import EntityMapper
from fetch_ravenpack import RavenPackClient
from db import DatabaseOperation
from newspulse import NewsPulseCalculator
from datetime import timedelta
import yfinance as yf
import math

def sanitize_float(val, default=0.0):
    if val is None or (isinstance(val, (float, int)) and (math.isnan(val) or math.isinf(val))):
        return default
    return float(val)

logger = logging.getLogger(__name__)

try:
    from fds.fpe.fql import FQLX
    HAS_FACTSET = True
    logger.info("FactSet SDK (fds.fpe) successfully imported.")
except ImportError:
    HAS_FACTSET = False
    logger.warning("FactSet SDK (fds.fpe) not found. Sector lookup will be skipped.")

# Global instances for both API and pipeline use
app = FastAPI(title="Cooper Data API")

# CORS — allow React dev server (port 3000 / 5173) to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

db_ops = DatabaseOperation()
rp_client = RavenPackClient()
np_calc = NewsPulseCalculator()

mapping_file = os.path.join(os.path.dirname(__file__), "RPA_entity-mapping.csv")

def get_mapper(job_id: int):
    return EntityMapper(mapping_file, job_id=job_id)

# Global mapper for search to avoid re-reading 143MB CSV on every request
search_mapper = EntityMapper(mapping_file, job_id=0)

target_sedols = ["688910", "647295", "659704", "BW4F6F", "BZ0RDZ", "664048", "680448"]

def get_all_target_sedols():
    base_sedols = target_sedols
    try:
        shorts_sedols = db_ops.get_shorts_sedols()
        return list(set(base_sedols + shorts_sedols))
    except Exception as e:
        logger.error(f"Failed to get short dataset SEDOLs: {e}")
        return base_sedols

# Base Logging configuration
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def adapt_ravenpack_data(df: pd.DataFrame, rp_entity_id: str, job_id: int) -> pd.DataFrame:
    """ Maps raw API data columns to local required DataFrame structure """
    col_map = {
        'TIMESTAMP_UTC': 'timestamp',
        'EVENT_SENTIMENT_SCORE': 'sentiment',
        'RELEVANCE': 'relevance',
        'ESS': 'ess',
        'ENTITY_NAME': 'entity_name',   # Capture display name from RavenPack
    }
    
    # Capitalize the cols mapping correctly
    df.rename(columns=lambda x: col_map.get(x.upper(), x.lower()), inplace=True)
    
    # Inject required identifiers
    df['rp_entity_id'] = rp_entity_id
    df['job_id'] = job_id

    # ESS fallback: if no dedicated ESS column, use sentiment score directly
    if 'ess' not in df.columns and 'sentiment' in df.columns:
        df['ess'] = df['sentiment']

    # entity_name fallback: fill any missing values with rp_entity_id so it's never null
    if 'entity_name' not in df.columns:
        df['entity_name'] = rp_entity_id
    else:
        df['entity_name'] = df['entity_name'].fillna(rp_entity_id)
        
    return df
@app.on_event("startup")
def startup_event():
    # Database Setup
    try:
        logger.info("Database Setup")
        db_ops.create_table_if_not_exists()
        db_ops.create_analytics_table_if_not_exists()
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Failed to connect to database. Please check credentials in .env: {e}")
        return

@app.get("/health")
def health_check():
    return {"status": "ok"}

@app.get("/job-details")
def get_pipeline_details(id: int = None):
    try:
        if id:
            return db_ops.get_pipeline_details(id)
        else:
            return db_ops.get_pipeline_details()
    except Exception as e:
        logger.error(f"Failed to get pipeline details: {e}")
        return {"status": "failed"}

@app.get("/portfolio-sentiment")
def get_portfolio_sentiment():
    """
    Returns the latest per-stock News Pulse (TimeWeighted) for treemap rendering.
    """
    try:
        data = db_ops.get_portfolio_sentiment(target_sedols=target_sedols)
        if not data:
            return JSONResponse(
                status_code=status.HTTP_404_NOT_FOUND,
                content={
                    "status": "no_data",
                    "message": "No completed NPA job found. Run /news-pulse/calculate first."
                }
            )
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"status": "ok", "count": len(data), "data": data}
        )
    except Exception as e:
        logger.error(f"Error in /portfolio-sentiment: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(e)}
        )

def run_pipeline(job_id, start_date: datetime, end_date: datetime):

    log_to_db(job_id, log_type="cron_job", log_from="main.py",
    log_title="Cron Job Started", 
    log_message=f"Starting Cron Job at date - {datetime.now().date()} and time - {datetime.now().time()}", function_name="main.py")

    active_sedols = get_all_target_sedols()
    log_to_db(job_id, log_type="pipeline", log_from="main.py",
    log_title="Targeted Sedols", 
    log_message=f"Starting RavenPack Fetch for {active_sedols}, and looking to the RPA_entity-mapping.csv file for the RP_ENTITY_ID", function_name="main.py")
    
    mapping_file = os.path.join(os.path.dirname(__file__), "RPA_entity-mapping.csv")
    if not os.path.exists(mapping_file):
        log_to_db(job_id, log_type="corn_job", log_from="main.py", log_title="Mapping CSV Not Found", log_message=f"RPA_entity-mapping.csv Mapping file not found at {mapping_file}", log_status=False, function_name="main.py")
        return
    
    log_to_db(job_id, log_type="pipeline", log_from="main.py",
    log_title="Pipeline Setup", 
    log_message=f"Spinning up Pipeline - Window: {start_date.date()} to {end_date.date()}", function_name="main.py")
    
    total_records_inserted = 0
    for sedol in active_sedols:
        log_to_db(job_id, log_type="pipeline", log_from="main.py",
        log_title="Pipeline Setup", 
        log_message=f"Triggered sequence bounds for SEDOL: {sedol}", function_name="main.py")
        
        # Phase 1: Retrieve Mapping
        rp_entity_id = get_mapper(job_id).get_rp_entity_id(sedol, end_date)
        if not rp_entity_id:
            log_to_db(job_id, log_type="pipeline", log_from="main.py",
            log_title="Pipeline Setup", 
            log_message=f"Aborting sequence on {sedol}: Unable to resolve RP_ENTITY_ID.",
            log_status=False, function_name="main.py")
            continue
            
        log_to_db(job_id, log_type="pipeline", log_from="main.py",
        log_title="Pipeline Setup", 
        log_message=f"Resolved SEDOL: {sedol} -> RP_ENTITY_ID: {rp_entity_id}", function_name="main.py")
        
        # Phase 2: Fetch Data Incrementally
        latest_db_ts = db_ops.get_max_timestamp(rp_entity_id)
        
        # Incremental Fetch Logic: Start from whichever is LATER (request vs DB)
        # Adding a 1-second buffer if data exists to avoid pulling the same edge record
        if latest_db_ts:
            effective_start = max(start_date, latest_db_ts + timedelta(seconds=1))
        else:
            effective_start = start_date
            
        log_to_db(job_id, log_type="pipeline", log_from="main.py",
        log_title="Pipeline Setup", 
        log_message=f"Initiating fetch from {effective_start} to catch up (Window End: {end_date.date()})...", function_name="main.py")
        
        # Phase 2 & 3: Adaptive Window Fetch (Solves 10,000 record limit efficiently)
        try:
            raw_news_df = rp_client.fetch_news_adaptive(
                rp_entity_id=rp_entity_id, 
                start_date=effective_start, 
                end_date=end_date, 
                job_id=job_id,
                min_relevance=80
            ) 
            
            if not raw_news_df.empty:
                # Schema Alignment & DB Batch Commit
                mapped_df = adapt_ravenpack_data(raw_news_df, rp_entity_id, job_id)
                db_ops.insert_data_batch(mapped_df, job_id, skip_cleanup=True)
                count = len(raw_news_df)
                total_records_inserted += count
                log_to_db(job_id, log_type="corn_job", log_from="main.py", log_title="Database Insert", log_message=f"Adaptive fetch complete for {sedol}. New records added: {count}", function_name="main.py")
            else:
                log_to_db(job_id, log_type="corn_job", log_from="main.py", log_title="Fetch Result", log_message=f"No new records returned for {rp_entity_id}.", function_name="main.py")
        
        except Exception as e:
            log_to_db(job_id, log_type="corn_job", log_from="main.py", log_title="Adaptive Fetch Error", log_message=f"Unrecoverable error in adaptive fetch for {rp_entity_id}: {e}", log_status=False, function_name="main.py")
            db_ops.update_pipeline_status(job_id, "Pipeline failed", False)
            return False, f"Unrecoverable error in adaptive fetch for {rp_entity_id}: {e}"

    # Single cleanup entry at end of pipeline cycle
    from db import NewsData
    db_ops.cleanup_active_data(NewsData, 'timestamp')

    db_ops.update_pipeline_status(job_id, "Pipeline cycle completed successfully", True)
    return True, f"Total new records added: {total_records_inserted}"

def calculate_news_pulse(job_id):
    latest_pipeline_details = db_ops.get_pipeline_details(job_id)
    if not latest_pipeline_details or not latest_pipeline_details.is_pipeline_done:
        return {"status": "failed", "message": f"Pipeline not completed for job_id {latest_pipeline_details.id if latest_pipeline_details else 'N/A'}"}
    
    if latest_pipeline_details.is_npa_done:
        return {"status": "success", "message": f"NPA calculation already complete for job_id {latest_pipeline_details.id}"}

    if latest_pipeline_details.status == "NPA calculation started":
        return {"status": "in_progress", "message": f"NPA calculation already in progress for job_id {latest_pipeline_details.id}"}
    db_ops.update_npa_status(job_id, "NPA calculation started", False)
    db_ops.update_npa_start_time(job_id)

    # Analytics Lookback: Ensure we pull enough history to satisfy the 90-day active window
    # even if the latest job was only for a short period.
    from config import DATA_RETENTION_DAYS
    retention_cutoff = datetime.now() - timedelta(days=DATA_RETENTION_DAYS)
    
    # We take the earlier of the requested window or the retention cutoff
    start_date = min(latest_pipeline_details.req_start_date, retention_cutoff)
    end_date = latest_pipeline_details.req_end_date

    try:
        mapper = get_mapper(job_id)
        active_sedols = get_all_target_sedols()
        for sedol in active_sedols:

            rp_entity_id = mapper.get_rp_entity_id(sedol, end_date)
            if not rp_entity_id:
                log_to_db(job_id, log_type="corn_job", log_from="main.py",
                log_title="Pipeline Setup", 
                log_message=f"Aborting sequence on {sedol}: Unable to resolve RP_ENTITY_ID.",
                log_status=False, function_name="main.py")
                continue

            log_to_db(job_id, log_type="corn_job", log_from="main.py", log_title="Analytics Started", log_message=f"Solving numeric aggregates for {sedol} ({rp_entity_id}) utilizing full Database historical storage...", function_name="main.py")
            db_history_df = db_ops.fetch_historical_data(
                rp_entity_id=rp_entity_id, 
                start_date=start_date.strftime("%Y-%m-%d"), 
                end_date=end_date.strftime("%Y-%m-%d")
            )
            
            # Tag SEDOL and ID back into historical frame for dynamic downstream groupby grouping map
            db_history_df['SEDOL'] = sedol
            db_history_df['RP_ENTITY_ID'] = rp_entity_id
            db_history_df['rp_entity_id'] = rp_entity_id
            
            np_df = np_calc.calculate(db_history_df, end_date)
            
            # Produce Artifact and Update Analytical Backend
            np_df['job_id'] = job_id
            
            log_to_db(job_id, log_type="corn_job", log_from="main.py", log_title="Database Insert", log_message=f"Uploading Analytical Pulse for {sedol} into PostgreSQL Table 'news_pulse_analytics'...", function_name="main.py")
            db_ops.insert_analytics_batch(np_df, job_id, skip_cleanup=True)
            
            log_to_db(job_id, log_type="corn_job", log_from="main.py", log_title="Sequence Completed", log_message=f"Completed Time Series for {sedol}.", function_name="main.py")
            
            # Enforce rate delay safely locally to prevent heavy bursts to the network layer
            time.sleep(1)

        # Single cleanup entry at end of NPA calculation
        from db import NewsPulseAnalytics
        db_ops.cleanup_active_data(NewsPulseAnalytics, 'dates')

        log_to_db(job_id, log_type="corn_job", log_from="main.py", log_title="Corn Job Finished", log_message="System finalized full pipeline traversal.", function_name="main.py")

        db_ops.update_npa_status(job_id, "NPA calculation completed", True)

        return True, f"NPA calculation completed for job_id {job_id}"

    except Exception as e:
        log_to_db(job_id, log_type="corn_job", log_from="main.py", log_title="Corn Job Failed", log_message=f"Unrecoverable error in corn job: {e}", log_status=False, function_name="main.py")
        db_ops.update_npa_status(job_id, "NPA calculation failed", False)
        return False,  f"Unrecoverable error in corn job: {e}"

@app.post("/run-pipeline")
def run_pipeline_and_calculate_news_pulse(months: int = 1, start_date: datetime = None, end_date: datetime = None):
    
    if start_date is None:
        end_date = datetime.now()
        start_date = end_date - relativedelta(months=months)
    else:
        end_date = end_date or datetime.now()
    
    job_id = db_ops.get_next_job_id(start_date=start_date, end_date=end_date)
    pipeline_status, pipeline_message = run_pipeline(job_id,start_date=start_date, end_date=end_date)
    npa_status, npa_message = calculate_news_pulse(job_id)
    if pipeline_status and npa_status:
        return JSONResponse(status_code=status.HTTP_200_OK, content={
            "status": "Success", 
            "job_id": job_id,
            "message": "Pipeline and NPA calculation completed",
            "pipeline_status": pipeline_status, 
        "pipeline_message": pipeline_message, 
        "npa_status": npa_status, 
        "npa_message": npa_message })
    else:
        return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content={
            "status": "Failed", 
            "job_id": job_id,
            "message": "Pipeline and NPA calculation failed",
            "pipeline_status": pipeline_status, 
            "pipeline_message": pipeline_message, 
            "npa_status": npa_status, 
            "npa_message": npa_message })

@app.post("/ravenpack/fetch-dataset")
def fetch_rp_dataset(dataset_id: str = "0B9027EC22B8D448FF9C3F1014329F5B", months: int = 3, start_date: datetime = None, end_date: datetime = None):
    """
    Triggers fetching and storing data for a specific RavenPack dataset.
    """
    try:
        if not start_date:
            end_date = end_date or datetime.now()
            start_date = end_date - relativedelta(months=months)
        else:
            end_date = end_date or datetime.now()

        job_id = db_ops.get_next_job_id(start_date=start_date, end_date=end_date)
        db_ops.update_pipeline_status(job_id, "Dataset Fetch Started", False)
        log_to_db(job_id, log_type="fetch_dataset_data", log_from="main.py", log_title="Dataset Fetch Started", log_message=f"Dataset fetch started for dataset {dataset_id}", log_status=True, function_name="fetch_rp_dataset", class_name="RavenPackClient")

        records = rp_client.fetch_dataset_data(dataset_id, start_date=start_date, end_date=end_date, job_id=job_id)
        if not records:
            db_ops.update_pipeline_status(job_id, "Dataset Fetch - No Data", True)
            log_to_db(job_id, log_type="fetch_dataset_data", log_from="main.py", log_title="Dataset Fetch - No Data", log_message=f"No records found for dataset {dataset_id}", log_status=False, function_name="fetch_rp_dataset", class_name="RavenPackClient")
            return JSONResponse(
                status_code=status.HTTP_404_NOT_FOUND,
                content={"status": "Failed", "job_id": job_id, "message": f"No records found for dataset {dataset_id}"}
            )
        
        # Phase 2: Reverse Mapping (RP_ID -> SEDOL) and FactSet Sector Lookup
        mapper = get_mapper(job_id)
        rp_to_sedol = {}
        sedols_to_lookup = []
        
        for rec in records:
            rp_id = rec.get("RP_ENTITY_ID") or rec.get("rp_entity_id")
            if rp_id:
                # Use record timestamp for point-in-time mapping if available
                rec_ts = rec.get("TIMESTAMP_UTC") or rec.get("timestamp_utc")
                mapping_date = pd.to_datetime(rec_ts) if rec_ts else end_date
                
                if rp_id not in rp_to_sedol:
                    sedol = mapper.get_sedol(rp_id, mapping_date)
                    if sedol:
                        rp_to_sedol[rp_id] = sedol
                        sedols_to_lookup.append(sedol)
                        log_to_db(job_id, "mapping", "main.py", "SEDOL Found", f"Mapped {rp_id} -> {sedol} for date {mapping_date.date()}", function_name="fetch_rp_dataset")
                    else:
                        log_to_db(job_id, "mapping", "main.py", "SEDOL Not Found", f"Could not find SEDOL for {rp_id} at {mapping_date.date()}", log_status=False, function_name="fetch_rp_dataset")
        
        # Phase 3: Sourcing sectors from FactSet and Fallback CSV
        sector_mapping = {}
        if not HAS_FACTSET:
            log_to_db(job_id, "factset", "main.py", "FactSet Status", "FactSet SDK (fds.fpe) not available. Relying entirely on fallback CSV.", log_status=False, function_name="fetch_rp_dataset")
            
        if HAS_FACTSET and sedols_to_lookup:
            log_to_db(job_id, "factset", "main.py", "FactSet Lookup", f"Sourcing sectors for {len(sedols_to_lookup)} unique SEDOLs from FactSet...", function_name="fetch_rp_dataset")
            try:
                # Remove duplicates for efficient API call
                unique_sedols = list(set(sedols_to_lookup))
                fql = FQLX(
                    symbols=unique_sedols,
                    formulas={'sector': 'GICS_SECTOR()'},
                    include_dates=False
                )
                fql.calculate()
                
                # fql.data is expected to be a DataFrame where index or a column is the symbol
                fs_df = fql.data
                if isinstance(fs_df, pd.DataFrame):
                    # Map each unique sedol to its sector from the result
                    for sedol in unique_sedols:
                        # Find the row for this sedol
                        if sedol in fs_df.index:
                            sector_mapping[sedol] = fs_df.loc[sedol, 'sector']
                        elif 'symbol' in fs_df.columns:
                            match = fs_df[fs_df['symbol'] == sedol]
                            if not match.empty:
                                sector_mapping[sedol] = match.iloc[0]['sector']
                
                log_to_db(job_id, "factset", "main.py", "FactSet Lookup Success", f"Retrieved sectors for {len(sector_mapping)} instruments", function_name="fetch_rp_dataset")
            except Exception as fs_err:
                log_to_db(job_id, "factset", "main.py", "FactSet Lookup Failed", f"Error calling FactSet: {fs_err}", log_status=False, function_name="fetch_rp_dataset")
        
        # Load Fallback CSV once
        fallback_csv_path = os.path.join(os.path.dirname(__file__), "fallback_sectors.csv")
        csv_sector_mapping = {}
        if os.path.exists(fallback_csv_path):
            try:
                fallback_df = pd.read_csv(fallback_csv_path)
                # Ensure columns are lowercase to match lookups
                fallback_df.columns = [c.lower().strip() for c in fallback_df.columns]
                if 'sedol' in fallback_df.columns and 'sector' in fallback_df.columns:
                    valid_df = fallback_df.dropna(subset=['sedol', 'sector'])
                    # Convert sedol to string in case they are parsed as numbers
                    valid_df['sedol'] = valid_df['sedol'].astype(str)
                    csv_sector_mapping = valid_df.set_index('sedol')['sector'].to_dict()
                    log_to_db(job_id, "fallback_csv", "main.py", "Fallback CSV Loaded", f"Loaded {len(csv_sector_mapping)} sector mappings from CSV.", function_name="fetch_rp_dataset")
                else:
                    log_to_db(job_id, "fallback_csv", "main.py", "Fallback CSV Format Error", "CSV missing required 'sedol' or 'sector' columns.", log_status=False, function_name="fetch_rp_dataset")
            except Exception as e:
                log_to_db(job_id, "fallback_csv", "main.py", "Fallback CSV Error", f"Error loading fallback CSV: {e}", log_status=False, function_name="fetch_rp_dataset")
        else:
             log_to_db(job_id, "fallback_csv", "main.py", "Fallback CSV Not Found", f"Fallback CSV not found at {fallback_csv_path}", log_status=False, function_name="fetch_rp_dataset")

        # Enrich records with FactSet sectors or fallback
        missing_sector_sedols = set()
        for rec in records:
            rp_id = rec.get("RP_ENTITY_ID") or rec.get("rp_entity_id")
            sedol = rp_to_sedol.get(rp_id)
            
            # Embed SEDOL explicitly for database storage
            rec["SEDOL"] = sedol
            rec["sedol"] = sedol

            if not sedol:
                rec["SECTOR"] = None
                rec["sector"] = None
                continue
            
            sector_val = None
            # Check FactSet first
            if sedol in sector_mapping and pd.notna(sector_mapping[sedol]):
                sector_val = sector_mapping[sedol]
            
            # Check Fallback CSV
            if pd.isna(sector_val) or not sector_val:
                sector_val = csv_sector_mapping.get(sedol)
                if pd.notna(sector_val) and sector_val:
                    log_to_db(job_id, "fallback_csv", "main.py", "CSV Sector Fallback", f"Sector missing in FactSet for target SEDOL {sedol}, falling back to CSV.", function_name="fetch_rp_dataset")

            if pd.notna(sector_val) and sector_val:
                rec["SECTOR"] = sector_val
                rec["sector"] = sector_val
            else:
                missing_sector_sedols.add(sedol)
                rec["SECTOR"] = None
                rec["sector"] = None

        if missing_sector_sedols:
            log_to_db(job_id, "enrichment", "main.py", "Sector Not Found Summary", f"No sector mapped via FactSet or Fallback CSV for {len(missing_sector_sedols)} unique SEDOLs. Example: {list(missing_sector_sedols)[:5]}", log_status=False, function_name="fetch_rp_dataset")

        db_ops.insert_rp_dataset_data(dataset_id, records)
        db_ops.update_pipeline_status(job_id, "Dataset Fetch Completed", True)
        log_to_db(job_id, log_type="fetch_dataset_data", log_from="main.py", log_title="Dataset Fetch Completed", log_message=f"Successfully fetched and stored {len(records)} records", log_status=True, function_name="fetch_rp_dataset", class_name="RavenPackClient")
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"status": "Success", "job_id": job_id, "message": f"Successfully fetched and stored {len(records)} records"}
        )
    except Exception as e:
        log_to_db(job_id, log_type="fetch_dataset_data", log_from="main.py", log_title="Dataset Fetch Failed", log_message=f"Error in /ravenpack/fetch-dataset: {e}", log_status=False, function_name="fetch_rp_dataset", class_name="RavenPackClient")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "Failed", "message": str(e)}
        )

@app.get("/ravenpack/dataset-data")
def get_rp_dataset_data(dataset_id: str = "0B9027EC22B8D448FF9C3F1014329F5B"):
    """
    Retrieves stored RavenPack dataset data.
    """
    try:
        data = db_ops.get_rp_dataset_data(dataset_id)
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"status": "ok", "count": len(data), "data": data}
        )
    except Exception as e:
        logger.error(f"Error in /ravenpack/dataset-data: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(e)}
        )

@app.get("/ravenpack/list-datasets")
def list_rp_datasets():
    """
    Lists RavenPack datasets that start with "Shorts_" or "Themes_" and provides their extracted screen names.
    """
    try:
        all_datasets = rp_client.list_datasets()
        filtered_datasets = []
        
        for ds in all_datasets:
            ds_name = ds.get('name') or ds.get('dataset_name') or ""
            if ds_name.startswith("Shorts_"):
                screen_name = ds_name.split("Shorts_", 1)[1]
                ds['screen_name'] = screen_name
                ds['type'] = 'Shorts'
                filtered_datasets.append(ds)
            elif ds_name.startswith("Themes_"):
                screen_name = ds_name.split("Themes_", 1)[1]
                ds['screen_name'] = screen_name
                ds['type'] = 'Themes'
                filtered_datasets.append(ds)
                
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"status": "ok", "datasets": filtered_datasets}
        )
    except Exception as e:
        logger.error(f"Error listing datasets: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(e)}
        )

@app.get("/stock/search")
def search_stocks(q: str):
    """
    Searches for stocks by SEDOL, ticker, or company name using the in-memory mapper.
    """
    try:
        results = search_mapper.search_entities(q)
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"status": "ok", "query": q, "results": results}
        )
    except Exception as e:
        logger.error(f"Error in /stock/search: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(e)}
        )

@app.get("/stock/details")
def get_stock_details(rp_entity_id: str, days: int = 90):
    """
    Returns News Pulse and top news for a specific stock.
    If data is missing for the past 90 days, attempts to fetch it on-the-fly.
    """
    try:
        end_dt = datetime.now()
        start_dt = end_dt - timedelta(days=days)
        
        # 1. Check if we have enough data in NewsDataHistory
        news_df = db_ops.fetch_historical_data(rp_entity_id, start_dt.strftime("%Y-%m-%d"), end_dt.strftime("%Y-%m-%d"))
        
        # If no data found, try to fetch from RP API
        if news_df.empty:
            logger.info(f"No data for {rp_entity_id} in DB. Fetching last {days} days from RavenPack...")
            job_id = db_ops.get_next_job_id(start_dt, end_dt)
            try:
                raw_news_df = rp_client.fetch_news_adaptive(
                    rp_entity_id=rp_entity_id, 
                    start_date=start_dt, 
                    end_date=end_dt, 
                    job_id=job_id,
                    min_relevance=80
                )
                if not raw_news_df.empty:
                    mapped_df = adapt_ravenpack_data(raw_news_df, rp_entity_id, job_id)
                    db_ops.insert_data_batch(mapped_df, job_id, skip_cleanup=True)
                    # Re-fetch after insert
                    news_df = db_ops.fetch_historical_data(rp_entity_id, start_dt.strftime("%Y-%m-%d"), end_dt.strftime("%Y-%m-%d"))
            except Exception as e:
                logger.error(f"On-the-fly fetch failed for {rp_entity_id}: {e}")
        
        # 2. Calculate News Pulse
        news_pulse_series = []
        if not news_df.empty:
            news_df['rp_entity_id'] = rp_entity_id
            pulse_df = np_calc.calculate(news_df, end_dt)
            if not pulse_df.empty:
                for _, row in pulse_df.iterrows():
                    news_pulse_series.append({
                        "date": str(row['Dates']),
                        "pulse": round(sanitize_float(row['News Pulse (TimeWeighted)']), 2)
                    })
        
        # 3. Get Top News
        top_news = db_ops.get_top_news(rp_entity_id, days=days)
        
        # 4. Try to find SEDOL and Name for header
        stock_name = "Unknown"
        if not news_df.empty and 'entity_name' in news_df.columns:
             stock_name = news_df['entity_name'].iloc[0] or "Unknown"
        
        # Fallback to mapper if name is still Unknown
        if stock_name == "Unknown":
            stock_name = search_mapper.get_entity_name(rp_entity_id)
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "status": "ok",
                "rp_entity_id": rp_entity_id,
                "name": stock_name,
                "news_pulse": news_pulse_series,
                "top_news": top_news
            }
        )
    except Exception as e:
        logger.error(f"Error in /stock/details: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(e)}
        )

@app.get("/stock/chart-data")
def get_stock_chart_data(rp_entity_id: str, ticker: str = None, start_date: str = None):
    """
    Returns News Pulse and Stock Price time series for a specific stock.
    """
    try:
        if not start_date:
            from dateutil.relativedelta import relativedelta
            start_dt = datetime.now() - relativedelta(months=1)
        else:
            start_dt = datetime.fromisoformat(start_date.replace("Z", ""))
        
        # 1. Fetch News Data from DB
        end_dt = datetime.now()
        news_df = db_ops.fetch_historical_data(rp_entity_id, start_dt.strftime("%Y-%m-%d"), end_dt.strftime("%Y-%m-%d"))
        
        news_pulse_series = []
        if not news_df.empty:
            news_df['rp_entity_id'] = rp_entity_id
            pulse_df = np_calc.calculate(news_df, end_dt)
            if not pulse_df.empty:
                for _, row in pulse_df.iterrows():
                    news_pulse_series.append({
                        "date": str(row['Dates']),
                        "pulse": sanitize_float(row['News Pulse (TimeWeighted)']),
                        "pulse_unweighted": sanitize_float(row['News Pulse (Unweighted)'])
                    })
        
        # 2. Fetch Yahoo Finance Price Data
        price_series = []
        if ticker:
            yf_ticker = yf.Ticker(ticker)
            price_df = yf_ticker.history(start=start_dt.strftime("%Y-%m-%d"))
            
            for idx, row in price_df.iterrows():
                price_series.append({
                    "date": idx.strftime("%Y-%m-%d"),
                    "price": float(row['Close'])
                })
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "status": "ok",
                "rp_entity_id": rp_entity_id,
                "ticker": ticker,
                "news_pulse": news_pulse_series,
                "price_data": price_series
            }
        )
    except Exception as e:
        logger.error(f"Error in /stock/chart-data: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(e)}
        )

@app.get("/stock/sentiment-history")
def get_sentiment_history(rp_entity_id: str):
    """
    Returns historical sentiment trend for a specific stock from NewsPulseAnalyticsHistory.
    """
    try:
        data = db_ops.get_sentiment_history(rp_entity_id)
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"status": "ok", "rp_entity_id": rp_entity_id, "data": data}
        )
    except Exception as e:
        logger.error(f"Error in /stock/sentiment-history: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(e)}
        )

@app.get("/shorts/data")
def get_shorts_data(dataset_filter: str = None, start_date: str = None, end_date: str = None, adtv_min: float = 10.0):
    """
    Retrieves dynamically generated rows for the Shorts Tab
    """
    try:
        data = db_ops.get_shorts_data(dataset_filter, exclude_sedols=target_sedols, start_date=start_date, end_date=end_date, adtv_min=adtv_min)
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"status": "ok", "count": len(data), "data": data}
        )
    except Exception as e:
        logger.error(f"Error in /shorts/data: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(e)}
        )

@app.get("/shorts/datasets/added")
def get_added_datasets():
    """
    Retrieves distinct datasets available in the local DB.
    """
    try:
        data = db_ops.get_added_datasets()
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"status": "ok", "datasets": data}
        )
    except Exception as e:
        logger.error(f"Error in /shorts/datasets/added: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(e)}
        )

@app.get("/themes/data")
def get_themes_data(dataset_filter: str = None):
    """
    Retrieves aggregated theme data.
    """
    try:
        data = db_ops.get_themes_data(dataset_filter)
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"status": "ok", "count": len(data), "data": data}
        )
    except Exception as e:
        logger.error(f"Error in /themes/data: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(e)}
        )

@app.get("/themes/sentiment-history")
def get_theme_sentiment_history(dataset_id: str, days: int = 365):
    """
    Returns aggregated historical sentiment trend for a specific theme.
    """
    try:
        data = db_ops.get_theme_sentiment_history(dataset_id, days=days)
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"status": "ok", "dataset_id": dataset_id, "data": data}
        )
    except Exception as e:
        logger.error(f"Error in /themes/sentiment-history: {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(e)}
        )
# if __name__ == "__main__":
#     # Setup for command line run
#     try:
#         startup_event()
#         run_pipeline()
#     except Exception as e:
#         logger.error(f"Failed to run pipeline as script: {e}")