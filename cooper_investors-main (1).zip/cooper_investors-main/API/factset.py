from fds.sdk.OFDB import OFDB

# 1. Create an OFDB instance for your file
ofdb = OFDB()

ofdb.open('CLIENT:PCTIGR.OFDB')

# 2. Specify the fields you want to retrieve
fields = ['symbol', 'name', 'industry'] 

# 3. Specify the date you want (as a string in 'YYYYMMDD' format)
date = ['20250331']  # March 31, 2025

# 4. Pull the data for those fields and the specified date
data = ofdb.data(fields=fields, dates=date)

# 5. Display the result
data