import argparse
import pandas as pd
import logging
import os
from datetime import datetime
from db import DatabaseOperation

# Initialize DB
db_ops = DatabaseOperation()

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def adapt_history_csv(df: pd.DataFrame) -> pd.DataFrame:
    """Maps raw historical CSV data columns to local required DataFrame structure"""
    col_map = {
        'RP_ENTITY_ID': 'rp_entity_id',
        'TIMESTAMP_UTC': 'timestamp',
        'EVENT_SENTIMENT_SCORE': 'sentiment',
        'RELEVANCE': 'relevance',
        'ESS': 'ess'
    }

    df.rename(columns=lambda x: col_map.get(x.upper(), x.lower()), inplace=True)

    # Handle missing ESS
    if 'ess' not in df.columns and 'sentiment' in df.columns:
        df['ess'] = df['sentiment']

    return df


def upload_historical_file(csv_path: str, start_date: datetime, end_date: datetime):
    if not os.path.exists(csv_path):
        logger.error(f"Cannot locate CSV file: {csv_path}")
        return

    logger.info(f"Loading historical data from {csv_path}...")

    df = pd.read_csv(csv_path, encoding='latin1', low_memory=False)

    logger.info(f"Loaded {len(df)} rows. Mapping schema...")
    mapped_df = adapt_history_csv(df)

    required_cols = {'rp_entity_id', 'timestamp', 'sentiment', 'relevance'}
    if not required_cols.issubset(set(mapped_df.columns)):
        logger.error(f"Missing required columns: {required_cols - set(mapped_df.columns)}")
        return

    # Convert timestamp
    mapped_df['timestamp'] = pd.to_datetime(mapped_df['timestamp'], errors='coerce')
    mapped_df.dropna(subset=['timestamp', 'rp_entity_id'], inplace=True)

    # Generate job_id using passed parameters
    job_id = db_ops.get_next_job_id(start_date, end_date)
    mapped_df['job_id'] = job_id

    # Ensure ESS exists
    if 'ess' not in mapped_df.columns:
        mapped_df['ess'] = mapped_df.get('sentiment', 0)

    # DB operations
    db_ops.create_table_if_not_exists()

    logger.info(f"Inserting data for job_id={job_id} ...")
    db_ops.insert_data_batch(mapped_df)

    logger.info("--- Upload Complete ---")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Upload RavenPack Historical CSVs to PostgreSQL"
    )

    parser.add_argument(
        "csv_path",
        help="Path to the RavenPack history CSV file"
    )

    parser.add_argument(
        "--start_date",
        required=True,
        help="Start date (format: YYYY-MM-DD)"
    )

    parser.add_argument(
        "--end_date",
        required=True,
        help="End date (format: YYYY-MM-DD)"
    )

    args = parser.parse_args()

    # Convert string to datetime
    try:
        start_date = datetime.strptime(args.start_date, "%Y-%m-%d")
        end_date = datetime.strptime(args.end_date, "%Y-%m-%d")
    except ValueError:
        logger.error("Invalid date format. Use YYYY-MM-DD")
        exit(1)

    upload_historical_file(
        args.csv_path,
        start_date,
        end_date
    )