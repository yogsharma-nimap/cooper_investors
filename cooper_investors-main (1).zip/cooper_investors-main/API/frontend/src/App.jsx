import React, { useState } from "react";
import PortfolioTab from "./components/tabs/PortfolioTab/index";
import ClustersTab  from "./components/tabs/ClustersTab/index";
import ShortsTab    from "./components/tabs/ShortsTab/index";
import ThemesTab    from "./components/tabs/ThemesTab/index.jsx";
import SearchTab    from "./components/tabs/SearchTab/index.jsx";
import "./App.css";

const TABS = [
  { 
    id: "portfolio", 
    label: "PORTFOLIO", 
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10"/><path d="M8 12h8"/><path d="M12 8v8"/>
      </svg>
    ) 
  },
  { 
    id: "clusters",  
    label: "CLUSTERS",  
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
      </svg>
    )
  },
  { 
    id: "shorts",    
    label: "SHORTS",    
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="m3 19 6-6 4 4 8-8"/><path d="M15 7h6v6"/>
      </svg>
    )
  },
  { 
    id: "themes",    
    label: "THEMES",    
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 2v20"/><path d="m4.93 4.93 14.14 14.14"/><path d="M2 12h20"/><path d="m19.07 4.93-14.14 14.14"/>
      </svg>
    )
  },
  { 
    id: "search",    
    label: "SEARCH",    
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
    )
  },
];

function TabContent({ activeTab }) {
  switch (activeTab) {
    case "portfolio": return <PortfolioTab />;
    case "clusters":  return <ClustersTab />;
    case "shorts":    return <ShortsTab />;
    case "themes":    return <ThemesTab />;
    case "search":    return <SearchTab />;
    default:          return <PortfolioTab />;
  }
}

export default function App() {
  const [activeTab, setActiveTab] = useState("portfolio");

  const getPageTitle = (tab) => {
    const titles = {
      portfolio: "Portfolio Sentiment",
      clusters: "Sentiment Clusters",
      shorts: "Short Positions",
      themes: "Theme Periodicity",
      search: "Stock Intelligence",
    };
    return titles[tab] || "Portfolio Sentiment";
  };

  const getPageSubtitle = (tab) => {
    const subtitles = {
      portfolio: "",
      clusters: "",
      shorts: "",
      themes: "Analyzing CORE Data-Sets sentiment flux.",
      search: "Deep dive into specific asset sentiment history.",
    };
    return subtitles[tab] || "";
  };

  return (
    <div className="app-shell">
      {/* ── Top Bar ─────────────────────────────────── */}
      <header className="topbar">
        <div className="topbar-brand">
          <div className="brand-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/>
            </svg>
          </div>
          <div className="brand-text">
            <span className="brand-name">CORE</span>
            <span className="brand-sub">CORIANDER OBJECTIVE READING ENGINE</span>
          </div>
        </div>
        <button className="settings-btn" aria-label="Settings">⚙</button>
      </header>

      {/* ── Main Content ────────────────────────────── */}
      <main className="main-content">
        {/* Page title row */}
        <div className="page-title-row">
          <div>
            <div className="page-tag">INTELLIGENCE ENGINE</div>
            <h1 className="page-title">{getPageTitle(activeTab)}</h1>
            {getPageSubtitle(activeTab) && (
              <p className="page-subtitle">{getPageSubtitle(activeTab)}</p>
            )}
          </div>
          <button className="more-btn" aria-label="More options">⋮</button>
        </div>

        {/* Active tab content */}
        <div className="tab-content">
          <TabContent activeTab={activeTab} />
        </div>
      </main>

      {/* ── Bottom Tab Nav ──────────────────────────── */}
      <nav className="bottom-nav">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            id={`tab-${tab.id}`}
            className={`nav-tab ${activeTab === tab.id ? "active" : ""}`}
            onClick={() => setActiveTab(tab.id)}
            aria-label={tab.label}
          >
            <span className="nav-icon">{tab.icon}</span>
            <span className="nav-label">{tab.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}
