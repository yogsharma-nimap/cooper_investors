import { SEDOL } from "../config/sedolMap";

// Sentiment colors matching the CORE design (screenshot)
export const SENTIMENT_COLORS = {
  bullish: "#b3c4f5",  // blue-purple
  bearish: "#f4a07a",  // salmon/orange
  neutral: "#6b7fa3",  // muted steel blue
};

/**
 * Classify sentiment based on news_pulse_timeweighted value.
 */
export function getSentiment(pulse) {
  if (pulse > 0) return "bullish";
  if (pulse < 0) return "bearish";
  return "neutral";
}

export function getSentimentColor(pulse) {
  if (pulse >= 75) return "#9baefaff"; // Bluish (Deep)
  if (pulse >= 50) return "#b3c4f5"; // Lighter blue
  if (pulse > 0) return "#94a3b8";  // Greyish
  return "#f4a07a";                 // Orange shade
}

/**
 * Transforms raw API data into @nivo/treemap compatible format.
 *
 * Treemap size  = |news_pulse_timeweighted| (absolute value → bigger score = bigger tile)
 * Treemap color = sign of news_pulse_timeweighted (positive = bullish blue, negative = bearish salmon)
 */
export function transformToTreemapData(apiData, limit = 6) {
  if (!apiData || apiData.length === 0) return { name: "portfolio", children: [] };

  // Sort by absolute pulse descending so largest tiles appear first
  const sorted = [...apiData].sort(
    (a, b) => Math.abs(b.news_pulse_timeweighted) - Math.abs(a.news_pulse_timeweighted)
  );

  const topStocks = sorted.slice(0, limit);
  const otherStocks = sorted.slice(limit);

  const children = topStocks.map((item) => {
    const pulse = item.news_pulse_timeweighted ?? 0;
    const sentiment = getSentiment(pulse);
    return {
      id: item.sedol,
      name: SEDOL[item.sedol] ?? item.sedol,
      value: Math.max(Math.abs(pulse), 1), // never 0 so tile always has size
      pulse,
      label: `${pulse.toFixed(1)}%`,
      sentiment,
      color: getSentimentColor(pulse),
      sedol: item.sedol,
      latestDate: item.latest_date,
      psnTW: item.psn_timeweighted,
      nsnTW: item.nsn_timeweighted,
      rp_entity_id: item.rp_entity_id,
      entity_name: item.entity_name || item.name || SEDOL[item.sedol] || item.sedol,
    };
  });

  // Collapse remaining stocks into an "Others" group
  if (otherStocks.length > 0) {
    const othersAvgPulse =
      otherStocks.reduce((sum, s) => sum + (s.news_pulse_timeweighted ?? 0), 0) /
      otherStocks.length;
    const othersSentiment = getSentiment(othersAvgPulse);
    children.push({
      id: "others",
      name: `OTHERS (${otherStocks.length})`,
      value: Math.max(Math.abs(othersAvgPulse), 0.5),
      pulse: othersAvgPulse,
      label: `${othersAvgPulse.toFixed(1)}%`,
      sentiment: othersSentiment,
      color: "#3a4a6b",
      isOthers: true,
      entity_name: `OTHERS (${otherStocks.length})`,
    });
  }

  return { name: "portfolio", children };
}
