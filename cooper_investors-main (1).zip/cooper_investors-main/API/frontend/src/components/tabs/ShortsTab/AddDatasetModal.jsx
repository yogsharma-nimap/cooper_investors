import React, { useState, useEffect } from "react";
import "./AddDatasetModal.css";

export default function AddDatasetModal({ isOpen, onClose, onAddSuccess }) {
  const [datasets, setDatasets] = useState([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState("");
  const [selectedDatasetName, setSelectedDatasetName] = useState("");
  const [screenName, setScreenName] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    if (isOpen) {
      // Fetch available datasets from RavenPack API via backend
      const fetchDatasets = async () => {
        try {
          const response = await fetch("http://localhost:8000/ravenpack/list-datasets");
          const data = await response.json();
          if (data.status === "ok" && data.datasets) {
            const onlyShorts = data.datasets.filter(ds => ds.type === 'Shorts');
            setDatasets(onlyShorts);
            if (onlyShorts.length > 0) {
              const firstItem = onlyShorts[0];
              const fId = firstItem.uuid || firstItem.id || firstItem.dataset_id;
              const fName = firstItem.name || firstItem.dataset_name || fId;
              const fScreen = firstItem.screen_name || fName;
              setSelectedDatasetId(fId);
              setSelectedDatasetName(fName);
              setScreenName(fScreen);
            }
          }
        } catch (err) {
          console.error("Failed to load datasets:", err);
          setDatasets([]);
          setSelectedDatasetId("");
          setSelectedDatasetName("Failed to load datasets");
        }
      };
      
      fetchDatasets();
      
      // Reset form states
      setIsDropdownOpen(false);
      setIsAdding(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSelect = (id, name, sName) => {
    setSelectedDatasetId(id);
    setSelectedDatasetName(name);
    setScreenName(sName || name);
    setIsDropdownOpen(false);
  };

  const handleAdd = async () => {
    if (!selectedDatasetId) return;
    
    setIsAdding(true);
    try {
      const response = await fetch(`http://localhost:8000/ravenpack/fetch-dataset?dataset_id=${selectedDatasetId}`, {
        method: "POST"
      });
      const data = await response.json();
      if (response.ok && data.status === "Success") {
        onAddSuccess(); // trigger parent refresh
        onClose();
      } else {
        console.error("Failed to add dataset:", data.message);
        alert("Error mapping dataset: " + data.message);
      }
    } catch (err) {
      console.error("Network error adding dataset:", err);
      alert("Network error: Could not connect to API.");
    } finally {
      setIsAdding(false);
    }
  };

  return (
    <div className="modal-overlay open" onClick={onClose}>
      <div className="add-dataset-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">Add Short Data-set</h2>
          <button className="modal-close" onClick={onClose}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        <div className="modal-body">
          <div className="form-group">
            <label className="form-label">SELECT SHORT DATA-SET FROM RAVENPACK</label>
            <div className="modal-select-container">
              <div 
                className={`modal-select-trigger ${isDropdownOpen ? 'open' : ''}`} 
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              >
                <span>{selectedDatasetName || "Loading datasets..."}</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ opacity: 0.6 }}>
                  <path d="m7 15 5 5 5-5"/><path d="m7 9 5-5 5 5"/>
                </svg>
              </div>
              
              {isDropdownOpen && (
                <div className="modal-select-dropdown">
                  {datasets.map((ds, index) => {
                    const dsId = ds.uuid || ds.id || ds.dataset_id || `fallback-${index}`;
                    const dsName = ds.name || ds.dataset_name || dsId;
                    const dsScreen = ds.screen_name || dsName;
                    return (
                      <div 
                        key={dsId} 
                        className={`modal-select-item ${selectedDatasetId === dsId ? 'selected' : ''}`}
                        onClick={() => handleSelect(dsId, dsName, dsScreen)}
                      >
                        {dsName}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">AUTOMATIC SCREEN NAME</label>
            <input 
              type="text" 
              className="form-input" 
              readOnly
              style={{ background: 'rgba(255,255,255,0.05)', cursor: 'not-allowed' }}
              value={screenName}
            />
          </div>

          <button className="btn-modal-add" onClick={handleAdd} disabled={isAdding || !selectedDatasetId}>
            {isAdding ? "ADDING..." : "ADD"}
          </button>
        </div>
      </div>
    </div>
  );
}
