import React, { useState, useEffect } from "react";
import "./ShortsTab.css";
import AddDatasetModal from "./AddDatasetModal";

export default function ShortsTab() {
  const [availableDatasets, setAvailableDatasets] = useState([{ dataset_id: "All Data-Sets", dataset_name: "All Data-Sets" }]);
  const [selectedDatasetId, setSelectedDatasetId] = useState("All Data-Sets");
  const [selectedDatasetName, setSelectedDatasetName] = useState("All Data-Sets");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [tableData, setTableData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [adtvMin, setAdtvMin] = useState(10);
  const [selectedStock, setSelectedStock] = useState(null);
  const [isChartModalOpen, setIsChartModalOpen] = useState(false);

  // Fetch dropdown options for currently added datasets
  const fetchAvailableDatasets = async () => {
    try {
      const response = await fetch("http://localhost:8000/shorts/datasets/added");
      const data = await response.json();
      if (data.status === "ok" && data.datasets) {
        const onlyShorts = data.datasets.filter(ds => ds.type === 'Shorts');
        setAvailableDatasets(onlyShorts);
        // Retain selection if possible, otherwise default mapping
      }
    } catch (err) {
      console.error("Failed to fetch available datasets:", err);
    }
  };

  const fetchShortsData = async (datasetFilterId, stDate, enDate) => {
    setIsLoading(true);
    try {
      let url = new URL("http://localhost:8000/shorts/data");
      if (datasetFilterId && datasetFilterId !== "All Data-Sets") {
        url.searchParams.append("dataset_filter", datasetFilterId);
      }
      if (stDate) {
        url.searchParams.append("start_date", stDate);
      }
      if (enDate) {
        url.searchParams.append("end_date", enDate);
      }
      url.searchParams.append("adtv_min", adtvMin);
      const response = await fetch(url.toString());
      const data = await response.json();
      if (data.status === "ok") {
        setTableData(data.data || []);
      }
    } catch (error) {
      console.error("Failed to fetch shorts data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAvailableDatasets();
  }, []);

  useEffect(() => {
    fetchShortsData(selectedDatasetId, startDate, endDate);
  }, [selectedDatasetId, startDate, endDate, adtvMin]);

  const handleRefresh = () => {
    fetchAvailableDatasets();
    fetchShortsData(selectedDatasetId, startDate, endDate);
  };

  const formatValue = (val) => {
    const sign = val >= 0 ? "+" : "";
    return `${sign}${val.toFixed(2)}`;
  };

  const getValueClass = (val) => {
    return val < 0 ? "val-neg" : "val-pos";
  };

  return (
    <div className="shorts-tab">
      {/* Dataset Selection Row */}
      <div className="shorts-header-row">
        <div className="input-group">
          <label className="input-label">Short Data-Sets</label>
          <div className="dataset-dropdown-container">
            <div 
              className="custom-select-trigger" 
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            >
              <span>{selectedDatasetName}</span>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ opacity: 0.6 }}>
                <path d="m7 15 5 5 5-5"/><path d="m7 9 5-5 5 5"/>
              </svg>
            </div>
            
            {isDropdownOpen && (
              <div className="dropdown-menu">
                {availableDatasets.map((ds) => (
                  <div 
                    key={ds.dataset_id} 
                    className={`dropdown-item ${selectedDatasetId === ds.dataset_id ? 'selected' : ''}`}
                    onClick={() => {
                      setSelectedDatasetId(ds.dataset_id);
                      setSelectedDatasetName(ds.dataset_name);
                      setIsDropdownOpen(false);
                    }}
                  >
                    {ds.dataset_name}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        
        <div className="shorts-actions">
          <button className="btn-add" onClick={() => setIsModalOpen(true)}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"/><path d="M12 8v8"/><path d="M8 12h8"/>
            </svg>
            Add Data-set
          </button>
          <button className="btn-delete">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>
            </svg>
            Delete
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="filter-bar">
        <div className="date-inputs">
          <div className="date-field">
            <label className="input-label">Start Date</label>
            <div className="date-input-wrapper">
              <input 
                type="date" 
                className="date-input" 
                value={startDate} 
                onChange={(e) => setStartDate(e.target.value)} 
              />
            </div>
          </div>
          <div className="date-field">
            <label className="input-label">End Date</label>
            <div className="date-input-wrapper">
              <input 
                type="date" 
                className="date-input" 
                value={endDate} 
                onChange={(e) => setEndDate(e.target.value)} 
              />
            </div>
          </div>
        </div>
        
        <div className="filter-field">
          <label className="input-label">ADTV Min</label>
          <div className="adtv-input-wrapper">
            <input 
              type="number" 
              className="adtv-input" 
              value={adtvMin} 
              onChange={(e) => setAdtvMin(parseFloat(e.target.value) || 0)} 
            />
          </div>
        </div>
        
        <button className="btn-refresh" onClick={handleRefresh} disabled={isLoading}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ animation: isLoading ? 'spin 1s linear infinite' : 'none' }}>
            <path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/>
          </svg>
          {isLoading ? "Refreshing..." : "Refresh"}
        </button>
      </div>

      {/* Table */}
      <div className="shorts-table-container">
        <table className="shorts-table">
          <thead>
            <tr>
              <th>Sedol</th>
              <th>Company Name</th>
              <th>Country</th>
              <th>Short Screen Name</th>
              <th style={{ textAlign: 'right' }}>News Pulse (Latest)</th>
              <th style={{ textAlign: 'right' }}>Change (1W)</th>
            </tr>
          </thead>
          <tbody>
            {tableData.length === 0 && !isLoading && (
              <tr>
                <td colSpan="6" style={{ textAlign: "center", padding: "40px" }}>
                  No short data found for this selection.
                </td>
              </tr>
            )}
            {tableData.map((row, idx) => (
              <tr key={idx}>
                <td className="td-sedol">{row.sedol}</td>
                <td 
                  className="td-company clickable" 
                  onClick={() => {
                    setSelectedStock({
                      ...row,
                      entity_name: row.company // Align with modal expectations
                    });
                    setIsChartModalOpen(true);
                  }}
                >
                  {row.company}
                </td>
                <td>{row.country}</td>
                <td className="td-screen">{row.screen}</td>
                <td className={`td-value ${getValueClass(row.pulse)}`}>
                  {formatValue(row.pulse)}
                </td>
                <td className={`td-value ${getValueClass(row.change)}`}>
                  {formatValue(row.change)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <AddDatasetModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onAddSuccess={handleRefresh} 
      />

      {/* Historical Sentiment Chart Modal - Reused from Portfolio */}
      <SentimentTrendModal 
        isOpen={isChartModalOpen}
        onClose={() => setIsChartModalOpen(false)}
        stock={selectedStock}
      />
    </div>
  );
}

// Lazy load the shared modal to avoid circular/heavy imports if needed, 
// but for now we'll just import it normally.
import SentimentTrendModal from "../PortfolioTab/SentimentTrendModal";
