import React, { useState, useEffect, useRef } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown, CheckCircle, AlertTriangle } from "lucide-react";
import "./SearchTab.css";

export default function SearchTab() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [selectedStock, setSelectedStock] = useState(null);
  const [stockDetails, setStockDetails] = useState(null);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);
  const [detailsError, setDetailsError] = useState(null);
  const [selectedPeriod, setSelectedPeriod] = useState("3M");
  
  const searchRef = useRef(null);
  const periods = ["1W", "1M", "3M", "6M", "1Y"];

  const periodMap = {
    "1W": 7,
    "1M": 30,
    "3M": 90,
    "6M": 180,
    "1Y": 365
  };

  // Close search results when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setShowResults(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearchClick = async () => {
    if (searchQuery.length < 2) return;
    
    setIsSearching(true);
    setShowResults(true);
    try {
      const response = await fetch(`http://localhost:8000/stock/search?q=${encodeURIComponent(searchQuery)}`);
      const data = await response.json();
      if (data.status === "ok") {
        setSearchResults(data.results);
      }
    } catch (err) {
      console.error("Search failed:", err);
    } finally {
      setIsSearching(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      handleSearchClick();
    }
  };

  const selectStock = async (stock) => {
    setSelectedStock(stock);
    setSearchQuery(stock.name || stock.ticker || stock.sedol);
    setShowResults(false);
    fetchStockDetails(stock.rp_entity_id, selectedPeriod);
  };

  const fetchStockDetails = async (rp_entity_id, period) => {
    setIsLoadingDetails(true);
    setDetailsError(null);
    const days = periodMap[period] || 90;
    try {
      const response = await fetch(`http://localhost:8000/stock/details?rp_entity_id=${rp_entity_id}&days=${days}`);
      const data = await response.json();
      if (data.status === "ok") {
        setStockDetails(data);
      } else {
        setDetailsError(data.message || "Failed to load stock details.");
      }
    } catch (err) {
      console.error("Failed to fetch stock details:", err);
      setDetailsError("Connection to server failed. Please try again.");
    } finally {
      setIsLoadingDetails(false);
    }
  };

  useEffect(() => {
    if (selectedStock) {
      fetchStockDetails(selectedStock.rp_entity_id, selectedPeriod);
    }
  }, [selectedPeriod]);

  return (
    <div className="search-tab">
      {/* ── Search Bar Section ────────────────────────── */}
      <div className="search-header-controls">
        <div className="search-box-wrapper" ref={searchRef}>
          <div className="search-input-container">
            <svg className="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
            <input 
              type="text" 
              placeholder="Search by Company, Ticker, or SEDOL..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              onFocus={() => searchQuery.length >= 2 && searchResults.length > 0 && setShowResults(true)}
            />
            {isSearching && <div className="spinner-small" />}
            <button className="search-btn-trigger" onClick={handleSearchClick} disabled={isSearching}>
              SEARCH
            </button>
          </div>
          
          {showResults && searchResults.length > 0 && (
            <div className="search-results-dropdown">
              {searchResults.map((result) => (
                <div 
                  key={result.rp_entity_id} 
                  className="search-result-item"
                  onClick={() => selectStock(result)}
                >
                  <div className="result-main">
                    <span className="result-name">{result.name || "N/A"}</span>
                    <span className="result-ticker">{result.ticker}</span>
                  </div>
                  <div className="result-meta">
                    <span className="result-sedol">SEDOL: {result.sedol}</span>
                    <span className="result-id">ID: {result.rp_entity_id}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {selectedStock && (
          <div className="period-selector">
            {periods.map(p => (
              <button 
                key={p} 
                className={`period-tab ${selectedPeriod === p ? "active" : ""}`}
                onClick={() => setSelectedPeriod(p)}
              >
                {p}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ── Content Section ───────────────────────────── */}
      {!selectedStock ? (
        <div className="empty-state">
          <div className="empty-icon">🔍</div>
          <h2>Explore Asset Intelligence</h2>
          <p>Search for any stock to analyze its sentiment pulse and recent news events.</p>
        </div>
      ) : detailsError ? (
        <div className="error-state-card">
          <div className="error-icon">⚠</div>
          <h2>Analysis Failed</h2>
          <p>{detailsError}</p>
          <button className="retry-btn" onClick={() => fetchStockDetails(selectedStock.rp_entity_id, selectedPeriod)}>
            RETRY ANALYSIS
          </button>
        </div>
      ) : (
        <div className="stock-analysis-content">
          {isLoadingDetails ? (
            <div className="loading-overlay">
              <div className="pulse-loader" />
              <span>Analyzing News Pulse...</span>
            </div>
          ) : stockDetails && (
            <>
              {/* Header Info like Portfolio Modal */}
              <div className="analysis-header-card">
                <div className="stock-info-row">
                  <div className="stock-avatar">
                    {stockDetails.name?.substring(0, 2).toUpperCase()}
                  </div>
                  <div className="stock-info-text">
                    <h2>{stockDetails.name}</h2>
                    {stockDetails.news_pulse.length > 0 && (
                      <div className={`sentiment-badge ${stockDetails.news_pulse[stockDetails.news_pulse.length-1].pulse > 0 ? "bullish" : "bearish"}`}>
                        {stockDetails.news_pulse[stockDetails.news_pulse.length-1].pulse > 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                        <span>Sentiment Score: {stockDetails.news_pulse[stockDetails.news_pulse.length-1].pulse.toFixed(2)} ({stockDetails.news_pulse[stockDetails.news_pulse.length-1].pulse > 0 ? "Bullish" : "Bearish"})</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Chart Section */}
              <div className="analysis-card chart-card">
                <div className="card-header">
                  <h3>NEWS SENTIMENT TREND</h3>
                </div>
                <div className="chart-container">
                  <ResponsiveContainer width="100%" height={320}>
                    <AreaChart data={stockDetails.news_pulse} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                      <defs>
                        <linearGradient id="colorSentiment" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#b3c4f5" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="#b3c4f5" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#2d3748" />
                      <XAxis 
                        dataKey="date" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{fill: '#718096', fontSize: 12, dy: 10}}
                        tickFormatter={(val) => {
                          const d = new Date(val);
                          return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                        }}
                      />
                      <YAxis hide={true} domain={['dataMin - 5', 'dataMax + 5']} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#1a202c', border: 'none', borderRadius: '8px', color: '#fff' }}
                        itemStyle={{ color: '#a0aec0' }}
                        labelStyle={{ color: '#b3c4f5', marginBottom: '8px', fontWeight: 'bold' }}
                        labelFormatter={(label) => {
                          const d = new Date(label);
                          return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
                        }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="pulse" 
                        stroke="#b3c4f5" 
                        strokeWidth={3}
                        fillOpacity={1} 
                        fill="url(#colorSentiment)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* News Highlights Section formatted like Modal highlights */}
              <div className="news-highlights">
                {/* Positive News */}
                <div className="news-column positive">
                  <h4>TOP POSITIVE NEWS</h4>
                  <div className="news-list">
                    {stockDetails.top_news.positive.length > 0 ? stockDetails.top_news.positive.map((news, i) => (
                      <div key={i} className="news-highlight-item">
                        <CheckCircle size={24} className="icon" />
                        <div className="news-text">
                           <p>{news.entity_name} Sentiment: {news.ess.toFixed(2)}</p>
                           <span className="news-date-meta">{news.date}</span>
                        </div>
                      </div>
                    )) : (
                      <p className="no-highlights">No positive news found for this period.</p>
                    )}
                  </div>
                </div>

                {/* Negative News */}
                <div className="news-column negative">
                  <h4>TOP NEGATIVE NEWS</h4>
                  <div className="news-list">
                    {stockDetails.top_news.negative.length > 0 ? stockDetails.top_news.negative.map((news, i) => (
                      <div key={i} className="news-highlight-item">
                        <AlertTriangle size={24} className="icon" />
                        <div className="news-text">
                           <p>{news.entity_name} Sentiment: {news.ess.toFixed(2)}</p>
                           <span className="news-date-meta">{news.date}</span>
                        </div>
                      </div>
                    )) : (
                      <p className="no-highlights">No negative news found for this period.</p>
                    )}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
