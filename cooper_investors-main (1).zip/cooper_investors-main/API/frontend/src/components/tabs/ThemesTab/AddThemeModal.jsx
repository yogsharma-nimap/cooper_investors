import React, { useState, useEffect } from "react";
import "./AddThemeModal.css";

export default function AddThemeModal({ isOpen, onClose, onAddSuccess }) {
  const [datasets, setDatasets] = useState([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState("");
  const [selectedDatasetName, setSelectedDatasetName] = useState("");
  const [themeName, setThemeName] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    if (isOpen) {
      // Fetch available datasets from RavenPack API via backend (filtering for Themes)
      const fetchDatasets = async () => {
        try {
          const response = await fetch("http://localhost:8000/ravenpack/list-datasets");
          const data = await response.json();
          if (data.status === "ok" && data.datasets) {
            // Filter only Themes
            const themeDS = data.datasets.filter(ds => ds.type === 'Themes');
            setDatasets(themeDS);
            
            if (themeDS.length > 0) {
              const firstItem = themeDS[0];
              const fId = firstItem.uuid || firstItem.id || firstItem.dataset_id;
              const fName = firstItem.name || firstItem.dataset_name || fId;
              const fTheme = firstItem.screen_name || fName;
              setSelectedDatasetId(fId);
              setSelectedDatasetName(fName);
              setThemeName(fTheme);
            }
          }
        } catch (err) {
          console.error("Failed to load themes:", err);
          setDatasets([]);
          setSelectedDatasetId("");
          setSelectedDatasetName("Failed to load themes");
        }
      };
      
      fetchDatasets();
      
      // Reset form states
      setIsDropdownOpen(false);
      setIsAdding(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSelect = (id, name, tName) => {
    setSelectedDatasetId(id);
    setSelectedDatasetName(name);
    setThemeName(tName || name);
    setIsDropdownOpen(false);
  };

  const handleAdd = async () => {
    if (!selectedDatasetId) return;
    
    setIsAdding(true);
    try {
      // Use the same endpoint: it maps SEDOLs and saves to local DB
      const response = await fetch(`http://localhost:8000/ravenpack/fetch-dataset?dataset_id=${selectedDatasetId}&months=12`, {
        method: "POST"
      });
      const data = await response.json();
      if (response.ok && data.status === "Success") {
        onAddSuccess(); // trigger parent refresh
        onClose();
      } else {
        console.error("Failed to add theme dataset:", data.message);
        alert("Error mapping theme: " + data.message);
      }
    } catch (err) {
      console.error("Network error adding theme:", err);
      alert("Network error: Could not connect to API.");
    } finally {
      setIsAdding(false);
    }
  };

  return (
    <div className="modal-overlay open" onClick={onClose}>
      <div className="add-dataset-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">Add Theme Data-set</h2>
          <button className="modal-close" onClick={onClose}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        <div className="modal-body">
          <div className="form-group">
            <label className="form-label">SELECT THEME FROM RAVENPACK</label>
            <div className="modal-select-container">
              <div 
                className={`modal-select-trigger ${isDropdownOpen ? 'open' : ''}`} 
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              >
                <span>{selectedDatasetName || "Loading themes..."}</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ opacity: 0.6 }}>
                  <path d="m7 15 5 5 5-5"/><path d="m7 9 5-5 5 5"/>
                </svg>
              </div>
              
              {isDropdownOpen && (
                <div className="modal-select-dropdown">
                  {datasets.length === 0 ? (
                    <div className="modal-select-item" style={{opacity: 0.5}}>No Themes_ datasets found</div>
                  ) : (
                    datasets.map((ds, index) => {
                      const dsId = ds.uuid || ds.id || ds.dataset_id || `fallback-${index}`;
                      const dsName = ds.name || ds.dataset_name || dsId;
                      const dsTheme = ds.screen_name || dsName;
                      return (
                        <div 
                          key={dsId} 
                          className={`modal-select-item ${selectedDatasetId === dsId ? 'selected' : ''}`}
                          onClick={() => handleSelect(dsId, dsName, dsTheme)}
                        >
                          {dsName}
                        </div>
                      );
                    })
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">EXTRACTED THEME NAME</label>
            <input 
              type="text" 
              className="form-input" 
              readOnly
              style={{ background: 'rgba(255,255,255,0.05)', cursor: 'not-allowed' }}
              value={themeName}
            />
          </div>

          <button className="btn-modal-add" onClick={handleAdd} disabled={isAdding || !selectedDatasetId}>
            {isAdding ? "ENRICHING..." : "ADD THEME"}
          </button>
        </div>
      </div>
    </div>
  );
}
