import React, { useState, useEffect } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import "./ThemesTab.css";
import AddThemeModal from "./AddThemeModal";

export default function ThemesTab() {
  const [availableThemes, setAvailableThemes] = useState([]);
  const [selectedThemeId, setSelectedThemeId] = useState("");
  const [selectedThemeName, setSelectedThemeName] = useState("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState("ALL");
  const [isLoading, setIsLoading] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [sentimentTrendData, setSentimentTrendData] = useState([]);
  const [themeMetrics, setThemeMetrics] = useState({ pulse: 0, change: 0, stock_count: 0 });

  const periods = ["1W", "1M", "3M", "6M", "1Y"];

  const fetchAvailableThemes = async () => {
    try {
      const response = await fetch("http://localhost:8000/shorts/datasets/added");
      const data = await response.json();
      if (data.status === "ok" && data.datasets) {
        const themeDS = data.datasets.filter(ds => ds.type === 'Themes');
        setAvailableThemes(themeDS);
        if (themeDS.length > 0 && !selectedThemeId) {
          setSelectedThemeId(themeDS[0].dataset_id);
          setSelectedThemeName(themeDS[0].dataset_name);
        }
      }
    } catch (err) {
      console.error("Failed to fetch available themes:", err);
    }
  };

  const fetchThemeData = async (themeId) => {
    if (!themeId) return;
    setIsLoading(true);
    try {
      // 1. Fetch Metrics
      const metricsRes = await fetch(`http://localhost:8000/themes/data?dataset_filter=${themeId}`);
      const metricsData = await metricsRes.json();
      if (metricsData.status === "ok" && metricsData.data.length > 0) {
        const theme = metricsData.data[0];
        setThemeMetrics(prev => ({
          ...prev,
          pulse: theme.pulse,
          change: theme.change
        }));
      }

      // Period mapping to days
      const periodMap = {
        "1W": 7,
        "1M": 30,
        "3M": 90,
        "6M": 180,
        "1Y": 365
      };
      const days = periodMap[selectedPeriod] || 365;

      // 2. Fetch History
      const historyRes = await fetch(`http://localhost:8000/themes/sentiment-history?dataset_id=${themeId}&days=${days}`);
      const historyData = await historyRes.json();
      if (historyData.status === "ok") {
        const hData = historyData.data || [];
        setSentimentTrendData(hData);
        
        // Calculate normalized volatility from history if data exists
        if (hData.length > 1) {
            const values = hData.map(d => d.news_pulse);
            const mean = values.reduce((a, b) => a + b, 0) / values.length;
            const variance = values.reduce((a, b) => a + (b - mean) ** 2, 0) / values.length;
            const stdDev = Math.sqrt(variance);
            
            // VOLATILITY LOGIC:
            // Standard Deviation shows how much the sentiment score deviates from its own mean.
            // On a -100 to +100 scale, we consider an Std Dev of 25 as "High Volatility" (100%).
            let volPercent = (stdDev / 25) * 100;
            volPercent = Math.min(Math.max(volPercent, 0), 100);
            
            setThemeMetrics(prev => ({ ...prev, volatility: volPercent }));
        } else {
            setThemeMetrics(prev => ({ ...prev, volatility: 0 }));
        }
      }
    } catch (error) {
      console.error("Failed to fetch theme data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAvailableThemes();
  }, []);

  useEffect(() => {
    if (selectedThemeId) {
      fetchThemeData(selectedThemeId);
    }
  }, [selectedThemeId, selectedPeriod]);

  const handleThemeChange = (themeId, themeName) => {
    setSelectedThemeId(themeId);
    setSelectedThemeName(themeName);
    setIsDropdownOpen(false);
  };

  const handlePeriodChange = (period) => {
    setSelectedPeriod(period);
  };

  const handleRefresh = () => {
    fetchAvailableThemes();
    if (selectedThemeId) {
      fetchThemeData(selectedThemeId);
    }
  };

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="chart-tooltip">
          <div className="tooltip-date">{data.date}</div>
          <div className="tooltip-value">{data.news_pulse >= 0 ? "+" : ""}{data.news_pulse.toFixed(2)}</div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="themes-tab">
      {/* Top Row: Theme Selector, Periodicity Controls, Live Button */}
      <div className="themes-top-row">
        {/* Left: Theme Selector */}
        <div className="theme-selector-wrapper">
          <label className="section-label">Selected Theme</label>
          <div className="theme-dropdown-container">
            <button
              className="custom-select-trigger"
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            >
              <div className="trigger-content">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M16 21H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10" />
                  <path d="M8 11h8M8 15h8" />
                </svg>
                <span>{selectedThemeName || "No Themes Added"}</span>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="6 9 12 15 18 9"></polyline>
              </svg>
            </button>
            {isDropdownOpen && (
              <div className="dropdown-menu">
                {availableThemes.length === 0 ? (
                    <div className="dropdown-item" style={{opacity: 0.5}}>No themes available</div>
                ) : (
                    availableThemes.map((theme) => (
                    <div
                        key={theme.dataset_id}
                        className={`dropdown-item ${selectedThemeId === theme.dataset_id ? "selected" : ""}`}
                        onClick={() => handleThemeChange(theme.dataset_id, theme.dataset_name)}
                    >
                        {theme.dataset_name}
                    </div>
                    ))
                )}
              </div>
            )}
          </div>
        </div>

        {/* Middle: Periodicity Controls */}
        <div className="periodicity-controls-wrapper">
          <label className="section-label">Analysis Periodicity</label>
          <div className="period-buttons">
            {periods.map((period) => (
              <button
                key={period}
                className={`period-btn ${selectedPeriod === period ? "active" : ""}`}
                onClick={() => handlePeriodChange(period)}
              >
                {period}
              </button>
            ))}
          </div>
        </div>

        {/* Right: Actions */}
        <div className="theme-actions">
            <button className="btn-add-theme" onClick={() => setIsModalOpen(true)}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <line x1="12" y1="5" x2="12" y2="19"></line>
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                ADD THEME
            </button>
            <button
            className="btn-live"
            onClick={handleRefresh}
            disabled={isLoading}
            >
            <svg
                width="14"
                height="14"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                className={isLoading ? "spinning" : ""}
            >
                <polyline points="23 4 23 10 17 10"></polyline>
                <polyline points="1 20 1 14 7 14"></polyline>
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36M20.49 15a9 9 0 0 1-14.85 3.36"></path>
            </svg>
            LIVE
            </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="metrics-row">
        <div className="metric-card sentiment-metric">
          <div className="label-with-dot">
            <span className="blue-dot">●</span>
            <span className="metric-label">News Pulse</span>
          </div>
          <div className="metric-display">
            <span className={`metric-score ${themeMetrics.change >= 0 ? "up" : "down"}`}>
              {themeMetrics.pulse >= 0 ? "+" : ""}{themeMetrics.pulse.toFixed(2)}
            </span>
            <div className={`metric-change-wrapper ${themeMetrics.change >= 0 ? "up" : "down"}`}>
              <span className="metric-change-val">
                ({themeMetrics.change >= 0 ? "+" : ""}{themeMetrics.change.toFixed(2)})
              </span>
              <span className="metric-trend">
                {themeMetrics.change >= 0 ? "▲" : "▼"}
              </span>
            </div>
          </div>
        </div>

        <div className="metric-card volatility-metric">
          <span className="metric-label">Volatility</span>
          <div className="metric-display">
            <span className="metric-volatility">{(themeMetrics.volatility || 0).toFixed(1)}%</span>
          </div>
        </div>
      </div>

      {/* Chart Section - Mirroring Portfolio History Design */}
      <div className="chart-wrapper">
        {!isLoading && sentimentTrendData.length === 0 ? (
            <div className="no-data-overlay">No historical pulse data for this theme yet.</div>
        ) : (
            <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={sentimentTrendData} margin={{ top: 10, right: 10, left: 10, bottom: 5 }}>
                <defs>
                    <linearGradient id="themeColorSentiment" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#b3c4f5" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#b3c4f5" stopOpacity={0} />
                    </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#2d3748" />
                <XAxis
                    dataKey="date"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#718096', fontSize: 12, dy: 10 }}
                    tickFormatter={(val) => {
                        const d = new Date(val);
                        return isNaN(d.getTime()) ? val : d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                    }}
                    minTickGap={40}
                />
                <YAxis hide={true} domain={['dataMin - 5', 'dataMax + 5']} />
                <Tooltip
                    contentStyle={{ backgroundColor: '#1a202c', border: 'none', borderRadius: '8px', color: '#fff' }}
                    itemStyle={{ color: '#a0aec0' }}
                    labelStyle={{ color: '#b3c4f5', marginBottom: '8px', fontWeight: 'bold' }}
                    labelFormatter={(label) => {
                        const d = new Date(label);
                        return isNaN(d.getTime()) ? label : d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
                    }}
                    formatter={(value) => [value.toFixed(2), "News Pulse"]}
                />
                <Area
                    type="monotone"
                    dataKey="news_pulse"
                    stroke="#b3c4f5"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#themeColorSentiment)"
                    isAnimationActive={false}
                />
            </AreaChart>
            </ResponsiveContainer>
        )}
      </div>

      {/* Data Engine Footer */}
      <div className="data-engine-footer">
        <div className="engine-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <circle cx="12" cy="12" r="1" fill="currentColor" />
            <circle cx="12" cy="12" r="9" />
            <path d="M12 5v2m0 10v2M5 12H3m16 0h2" />
            <path d="M6.46 6.46l-1.42-1.42M18.96 18.96l-1.42-1.42M17.54 6.46l1.42-1.42M6.04 18.96l1.42-1.42" />
          </svg>
        </div>
        <div className="engine-info">
          <span className="engine-name">Thematic Aggregation Engine</span>
          <span className="engine-desc">Sourcing stocks from RavenPack datasets and averaging historical News Pulse from master table.</span>
        </div>
      </div>

      <AddThemeModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAddSuccess={handleRefresh}
      />
    </div>
  );
}
