import React from "react";

export default function ClustersTab() {
  return (
    <div style={{ color: "#8096b8", padding: "40px 0", textAlign: "center" }}>
      Clusters — Coming Soon
    </div>
  );
}
