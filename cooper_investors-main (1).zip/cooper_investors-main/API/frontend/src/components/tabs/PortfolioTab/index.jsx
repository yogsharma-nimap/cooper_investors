import React, { useMemo } from "react";
import { usePortfolioSentiment } from "../../../hooks/usePortfolioSentiment";
import { transformToTreemapData } from "../../../utils/treemapUtils";
import AssetExposureTreemap from "./AssetExposureTreemap";
import SentimentLegend from "./SentimentLegend";
import SentimentTrendModal from "./SentimentTrendModal";
import "./PortfolioTab.css";

export default function PortfolioTab() {
  const { data, loading, error } = usePortfolioSentiment();
  const [isExpanded, setIsExpanded] = React.useState(false);

  const treemapData = useMemo(() => transformToTreemapData(data, isExpanded ? 50 : 6), [data, isExpanded]);

  const [selectedStock, setSelectedStock] = React.useState(null);
  const [isModalOpen, setIsModalOpen] = React.useState(false);

  const handleStockClick = (nodeData) => {
    setSelectedStock(nodeData);
    setIsModalOpen(true);
  };

  return (
    <div className="portfolio-tab">
      {/* Section header */}
      <div className="portfolio-header">
        <span className="section-label">Asset Exposure</span>
        <SentimentLegend />
      </div>

      {/* Loading skeleton */}
      {loading && (
        <div className="treemap-skeleton">
          <div className="skeleton-block large" />
          <div className="skeleton-col">
            <div className="skeleton-block medium" />
            <div className="skeleton-row">
              <div className="skeleton-block small" />
              <div className="skeleton-block small" />
            </div>
          </div>
        </div>
      )}

      {/* Error state */}
      {!loading && error && (
        <div className="portfolio-error">
          <span className="error-icon">⚠</span>
          <p>{error}</p>
          <button
            className="retry-btn"
            onClick={() => window.location.reload()}
          >
            Retry
          </button>
        </div>
      )}

      {/* Treemap */}
      {!loading && !error && (
        <>
          <AssetExposureTreemap 
            data={treemapData} 
            onNodeClick={handleStockClick} 
            onExpandOthers={() => setIsExpanded(true)}
          />
        </>
      )}

      {/* Sentiment Trend Modal */}
      <SentimentTrendModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        stock={selectedStock} 
      />
    </div>
  );
}
