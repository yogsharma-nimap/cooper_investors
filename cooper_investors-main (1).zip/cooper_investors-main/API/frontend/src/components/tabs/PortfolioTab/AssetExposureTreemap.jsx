import React, { useState } from "react";
import { ResponsiveTreeMap } from "@nivo/treemap";
import { SENTIMENT_COLORS } from "../../../utils/treemapUtils";
import "./AssetExposureTreemap.css";

export default function AssetExposureTreemap({ data, onNodeClick, onExpandOthers }) {
  if (!data || !data.children || data.children.length === 0) {
    return (
      <div className="treemap-empty">
        <p>No sentiment data available.</p>
        <span>Run the pipeline and calculate NPA first.</span>
      </div>
    );
  }

  return (
    <div className="treemap-wrapper">
      <ResponsiveTreeMap
        data={data}
        identity="name"
        value="value"
        valueFormat={(v) => `${v.toFixed(1)}`}
        margin={{ top: 0, right: 0, bottom: 0, left: 0 }}
        tile="squarify"
        innerPadding={4}
        outerPadding={4}
        colors={(node) => node.data.color || SENTIMENT_COLORS.neutral}
        nodeOpacity={1}
        borderWidth={0}
        borderRadius={6}
        enableParentLabel={false}
        label={(node) => {
          const text = node.data.entity_name;
          if (!text || !node.width) return text || "";

          // Average char width estimate for 16px bold Inter font
          const charWidth = 9.5; 
          const padding = 16;
          const maxChars = Math.floor((node.width - padding) / charWidth);

          if (text.length > maxChars) {
            if (maxChars < 3) return ""; // Hide text if box is extremely thin
            return text.substring(0, maxChars - 3) + "...";
          }
          return text;
        }}
        labelTextColor={{ from: "color", modifiers: [["darker", 2.8]] }}
        labelSkipSize={40}
        orientLabel={false}
        animate={true}
        motionConfig="gentle"
        tooltip={({ node }) => {
          if (node.data.isOthers) return null;
          const { entity_name, pulse, psnTW, nsnTW, latestDate } = node.data;
          return (
            <div className="treemap-tooltip-nivo">
              <div className="tt-ticker">{entity_name}</div>
              <div className="tt-row">
                <span>News Pulse</span>
                <span className={`tt-value ${pulse > 0 ? "bullish-text" : pulse < 0 ? "bearish-text" : ""}`}>
                  {pulse?.toFixed(2)}%
                </span>
              </div>
              <div className="tt-row">
                <span>PSN (TW)</span>
                <span className="bullish-text">{psnTW?.toFixed(2)}</span>
              </div>
              <div className="tt-row">
                <span>NSN (TW)</span>
                <span className="bearish-text">{nsnTW?.toFixed(2)}</span>
              </div>
              {latestDate && (
                <div className="tt-row">
                  <span>As of</span>
                  <span>{latestDate}</span>
                </div>
              )}
            </div>
          );
        }}

        onMouseEnter={() => { }}
        onMouseMove={() => { }}
        onMouseLeave={() => { }}
        onClick={(node) => {
          if (node && node.data && !node.data.isOthers && onNodeClick) {
            onNodeClick(node.data);
          } else if (node && node.data && node.data.isOthers && onExpandOthers) {
            onExpandOthers();
          }
        }}
        theme={{
          labels: {
            text: {
              fontSize: 16,
              fontWeight: 700,
              fontFamily: "'Inter', sans-serif",
              letterSpacing: "0.04em",
            },
          },
        }}
      />
    </div>
  );
}

