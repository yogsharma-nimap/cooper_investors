import React from "react";
import "./SentimentLegend.css";

/**
 * Top-right legend showing Bullish / Bearish color pills.
 */
export default function SentimentLegend() {
  return (
    <div className="sentiment-legend">
      <div className="legend-item">
        <span className="legend-dot bullish" />
        <span className="legend-label">BULLISH</span>
      </div>
      <div className="legend-item">
        <span className="legend-dot bearish" />
        <span className="legend-label">BEARISH</span>
      </div>
    </div>
  );
}
