import React, { useState, useEffect, useMemo } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";
import { X, TrendingUp, TrendingDown, CheckCircle, AlertTriangle } from "lucide-react";
import "./SentimentTrendModal.css";

const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

const FILTERS = [
  { label: "1W", value: "1w" },
  { label: "1M", value: "1m" },
  { label: "3M", value: "3m" },
  { label: "6M", value: "6m" },
  { label: "12M", value: "12m" },
];

export default function SentimentTrendModal({ isOpen, onClose, stock }) {
  const [activeFilter, setActiveFilter] = useState("3m");
  const [historyData, setHistoryData] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen && stock?.rp_entity_id) {
      fetchHistory();
    }
  }, [isOpen, stock]);

  const [topNews, setTopNews] = useState({ positive: [], negative: [] });

  const fetchHistory = async () => {
    setLoading(true);
    try {
      // Fetch comprehensive details including Top News and News Pulse series
      const resp = await fetch(`${API_BASE_URL}/stock/details?rp_entity_id=${stock.rp_entity_id}&days=90`);
      const json = await resp.json();
      if (json.status === "ok") {
        // Use the calculated news_pulse series from the backend
        setHistoryData(json.news_pulse || []);
        setTopNews(json.top_news || { positive: [], negative: [] });
      }
    } catch (err) {
      console.error("Failed to fetch stock details:", err);
    } finally {
      setLoading(false);
    }
  };

  const filteredData = useMemo(() => {
    if (!historyData.length) return [];

    const now = new Date();
    let cutoff = new Date();

    switch (activeFilter) {
      case "1w": cutoff.setDate(now.getDate() - 7); break;
      case "1m": cutoff.setMonth(now.getMonth() - 1); break;
      case "3m": cutoff.setMonth(now.getMonth() - 3); break;
      case "6m": cutoff.setMonth(now.getMonth() - 6); break;
      case "12m": cutoff.setFullYear(now.getFullYear() - 1); break;
      default: cutoff.setMonth(now.getMonth() - 3);
    }

    const sortedData = [...historyData].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    
    // Deduplicate by date (keep latest value of the day) to ensure the chart curve and tooltip points align perfectly
    const uniqueMap = new Map();
    sortedData.forEach(d => {
       uniqueMap.set(d.date, d);
    });
    
    return Array.from(uniqueMap.values()).filter(d => new Date(d.date) >= cutoff);
  }, [historyData, activeFilter]);

  if (!isOpen) return null;

  const isBullish = stock.pulse > 0;

  return (
    <div className="sentiment-modal-overlay" onClick={onClose}>
      <div className="sentiment-modal-content" onClick={e => e.stopPropagation()}>
        <button className="modal-close-btn" onClick={onClose}>
          <X size={24} />
        </button>

        <div className="modal-header">
          <div className="stock-info">
            <div className="stock-avatar">
              {stock.entity_name?.substring(0, 2).toUpperCase()}
            </div>
            <div className="stock-details">
              <h2>{stock.entity_name}</h2>
              <div className={`sentiment-badge ${isBullish ? "bullish" : "bearish"}`}>
                {isBullish ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                <span>Sentiment Score: {stock.pulse?.toFixed(2)} ({isBullish ? "Bullish" : "Bearish"})</span>
              </div>
            </div>
          </div>
        </div>

        <div className="chart-section">
          <div className="chart-header">
            <h3>NEWS SENTIMENT TREND</h3>
            <div className="filter-tabs">
              {FILTERS.map(f => (
                <button
                  key={f.value}
                  className={`filter-tab ${activeFilter === f.value ? "active" : ""}`}
                  onClick={() => setActiveFilter(f.value)}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div className="chart-container">
            {loading ? (
              <div className="chart-loader">Loading history...</div>
            ) : historyData.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={filteredData} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                  <defs>
                    <linearGradient id="colorSentiment" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#b3c4f5" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#b3c4f5" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#2d3748" />
                  <XAxis
                    dataKey="date"
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#718096', fontSize: 12, dy: 10 }}
                    tickFormatter={(val) => {
                      const d = new Date(val);
                      return isNaN(d.getTime()) ? val : d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                    }}
                    minTickGap={40}
                  />
                  <YAxis hide={true} domain={['dataMin - 5', 'dataMax + 5']} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1a202c', border: 'none', borderRadius: '8px', color: '#fff' }}
                    itemStyle={{ color: '#a0aec0' }}
                    labelStyle={{ color: '#b3c4f5', marginBottom: '8px', fontWeight: 'bold' }}
                    labelFormatter={(label) => {
                      const d = new Date(label);
                      return isNaN(d.getTime()) ? label : d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="pulse"
                    stroke="#b3c4f5"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorSentiment)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="chart-no-data">No historical data found for this stock.</div>
            )}
          </div>
        </div>

        <div className="news-highlights">
          <div className="news-column positive">
            <h4>TOP POSITIVE NEWS</h4>
            {topNews.positive?.length > 0 ? (
              topNews.positive.slice(0, 2).map((news, idx) => (
                <div className="news-item" key={idx}>
                  <CheckCircle size={18} className="icon" />
                  <p>{news.event_text || news.entity_name || "Positive market event detected."}</p>
                </div>
              ))
            ) : (
              <p className="no-news">No significant positive news found.</p>
            )}
          </div>
          <div className="news-column negative">
            <h4>TOP NEGATIVE NEWS</h4>
            {topNews.negative?.length > 0 ? (
              topNews.negative.slice(0, 2).map((news, idx) => (
                <div className="news-item" key={idx}>
                  <AlertTriangle size={18} className="icon" />
                  <p>{news.event_text || news.entity_name || "Negative market event detected."}</p>
                </div>
              ))
            ) : (
              <p className="no-news">No significant negative news found.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
