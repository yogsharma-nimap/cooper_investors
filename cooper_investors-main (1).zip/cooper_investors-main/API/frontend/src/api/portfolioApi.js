import { API_BASE_URL } from "../config/sedolMap";

/**
 * Fetches the latest portfolio sentiment data from the FastAPI backend.
 * Returns an array of stock objects with News Pulse (TimeWeighted) scores.
 */
export async function fetchPortfolioSentiment() {
  const res = await fetch(`${API_BASE_URL}/portfolio-sentiment`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message || `API error: ${res.status}`);
  }
  const json = await res.json();
  return json.data; // array of stock sentiment objects
}
