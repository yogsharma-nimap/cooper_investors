// Maps SEDOLs (stored in DB) to human-readable ticker labels for the UI
export const SEDOL = {
  "688910": "DATA1",
  "647295": "DATA2",
  "659704": "DATA3",
  "BW4F6F": "DATA4",
  "BZ0RDZ": "DATA5",
  "664048": "DATA6",
  "680448": "DATA7",
};

// Base URL for the FastAPI backend
export const API_BASE_URL = "http://localhost:8000";
