import { useState, useEffect } from "react";
import { fetchPortfolioSentiment } from "../api/portfolioApi";

/**
 * Custom hook: loads portfolio sentiment data from the backend.
 * Manages loading, error, and data state automatically.
 */
export function usePortfolioSentiment() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    fetchPortfolioSentiment()
      .then((result) => setData(result || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return { data, loading, error };
}
