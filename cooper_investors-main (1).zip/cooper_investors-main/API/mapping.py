import pandas as pd
from datetime import datetime
from utils import log_to_db
import logging

logger = logging.getLogger(__name__)

class EntityMapper:
    """
    Handles mapping of SEDOLs to RP_ENTITY_ID based on the date using an Entity Reference file.
    Expects columns: RP_ENTITY_ID, ENTITY_TYPE, DATA_TYPE, DATA_VALUE, RANGE_START, RANGE_END
    """
    def __init__(self, mapping_file_path: str, job_id: int):
        self.mapping_file_path = mapping_file_path
        self.job_id = job_id
        log_to_db(job_id, log_type="mapping", log_from="mapping.py", log_title="Loading Mapping", log_message=f"Loading mapping from {mapping_file_path}...", function_name="__init__", class_name="EntityMapper")
        
        # Use latin1 encoding and low_memory=False as specified
        self.mapping_df = pd.read_csv(self.mapping_file_path, encoding='latin1', low_memory=False)
        
        self.mapping_df['RANGE_START'] = pd.to_datetime(self.mapping_df['RANGE_START'])
        self.mapping_df['RANGE_END'] = pd.to_datetime(self.mapping_df['RANGE_END']).fillna(pd.Timestamp('2099-12-31'))
        self.mapping_df['DATA_VALUE'] = self.mapping_df['DATA_VALUE'].astype(str)
        log_to_db(job_id, log_type="mapping", log_from="mapping.py", log_title="Mapping Loaded", log_message="Mapping loaded successfully.", function_name="__init__", class_name="EntityMapper")
        
    def get_rp_entity_id(self, sedol: str, target_date: datetime = None) -> str:
        """
        Retrieves the RP_ENTITY_ID for a given SEDOL at a specific point in time.
        Handles both 6 and 7 character SEDOLs by performing a prefix search if necessary.
        """
        query_date = pd.to_datetime(target_date) if target_date else pd.Timestamp.now()
        
        # 1. Try exact match
        matched = self.mapping_df[
            (self.mapping_df['DATA_TYPE'] == 'SEDOL') & 
            (self.mapping_df['DATA_VALUE'] == sedol) & 
            (self.mapping_df['RANGE_START'] <= query_date) & 
            (self.mapping_df['RANGE_END'] >= query_date)
        ]
        
        if not matched.empty:
            return str(matched['RP_ENTITY_ID'].iloc[0])
            
        # 2. Try prefix match (for 6-character fragments)
        if len(sedol) == 6:
            matched = self.mapping_df[
                (self.mapping_df['DATA_TYPE'] == 'SEDOL') & 
                (self.mapping_df['DATA_VALUE'].str.startswith(sedol)) & 
                (self.mapping_df['RANGE_START'] <= query_date) & 
                (self.mapping_df['RANGE_END'] >= query_date)
            ]
            if not matched.empty:
                # If multiple matches, return the first one
                return str(matched['RP_ENTITY_ID'].iloc[0])
        
        log_to_db(self.job_id, log_type="mapping", log_from="mapping.py", log_title="Mapping Missing", log_message=f"No RP_ENTITY_ID found for SEDOL: {sedol} at date: {query_date.date()}", log_status=False, function_name="get_rp_entity_id", class_name="EntityMapper")
        return None

    def get_sedol(self, rp_entity_id: str, target_date: datetime = None) -> str:
        """
        Retrieves the SEDOL for a given RP_ENTITY_ID at a specific point in time.
        """
        query_date = pd.to_datetime(target_date) if target_date else pd.Timestamp.now()
        
        matched = self.mapping_df[
            (self.mapping_df['DATA_TYPE'] == 'SEDOL') & 
            (self.mapping_df['RP_ENTITY_ID'] == rp_entity_id) & 
            (self.mapping_df['RANGE_START'] <= query_date) & 
            (self.mapping_df['RANGE_END'] >= query_date)
        ]
        
        if not matched.empty:
            sedol = str(matched['DATA_VALUE'].iloc[0])
            log_to_db(self.job_id, log_type="mapping", log_from="mapping.py", log_title="Mapping Success", log_message=f"Found SEDOL: {sedol} for RP_ENTITY_ID: {rp_entity_id}", function_name="get_sedol", class_name="EntityMapper")
            return sedol
            
        log_to_db(self.job_id, log_type="mapping", log_from="mapping.py", log_title="Mapping Missing", log_message=f"No SEDOL found for RP_ENTITY_ID: {rp_entity_id} at date: {query_date.date()}", log_status=False, function_name="get_sedol", class_name="EntityMapper")
        return None

    def search_entities(self, query: str, limit: int = 20) -> list:
        """
        Searches for entities by matching query against DATA_VALUE for SEDOL, TICKER, or NAME/ENTITY_NAME.
        Returns a list of unique entities.
        """
        q = str(query).lower()
        
        # Filter for relevant data types first to reduce search space
        search_df = self.mapping_df[self.mapping_df['DATA_TYPE'].isin(['SEDOL', 'TICKER', 'ENTITY_NAME', 'NAME'])]
        
        # Perform Case-Insensitive search
        matches = search_df[search_df['DATA_VALUE'].str.lower().str.contains(q, na=False)]
        
        # Limit results for performance
        if len(matches) > 100:
            matches = matches.head(100)
            
        # Group by RP_ENTITY_ID to provide a clean list of unique assets
        # We'll pick the most descriptive name/ticker for each.
        entities = {}
        for _, row in matches.iterrows():
            eid = row['RP_ENTITY_ID']
            if eid not in entities:
                entities[eid] = {
                    "rp_entity_id": eid,
                    "name": "",
                    "ticker": "",
                    "sedol": ""
                }
            
            dtype = row['DATA_TYPE']
            dval = row['DATA_VALUE']
            
            if dtype in ['ENTITY_NAME', 'NAME']:
                entities[eid]["name"] = dval
            elif dtype == 'TICKER':
                entities[eid]["ticker"] = dval
            elif dtype == 'SEDOL':
                entities[eid]["sedol"] = dval

        # Sort results: prioritizing those where name or ticker starts with the query
        result_list = list(entities.values())
        
        def sort_key(item):
            n = (item['name'] or "").lower()
            t = (item['ticker'] or "").lower()
            s = (item['sedol'] or "").lower()
            if n.startswith(q) or t.startswith(q) or s.startswith(q):
                return 0
            return 1

        result_list.sort(key=sort_key)
        return result_list[:limit]

    def get_entity_name(self, rp_entity_id: str) -> str:
        """
        Attempts to resolve an entity name from the mapping file using RP_ENTITY_ID.
        """
        if self.mapping_df is None:
            return "Unknown"
        
        match = self.mapping_df[
            (self.mapping_df['RP_ENTITY_ID'] == rp_entity_id) & 
            (self.mapping_df['DATA_TYPE'].isin(['ENTITY_NAME', 'NAME']))
        ]
        
        if not match.empty:
            return str(match.iloc[0]['DATA_VALUE'])
        return "Unknown"
