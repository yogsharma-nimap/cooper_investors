from utils import log_to_db
import requests
import pandas as pd
import time
import logging
from typing import Optional, Dict, Any, List
from datetime import datetime
from dateutil.relativedelta import relativedelta
import config

logger = logging.getLogger(__name__)

class RavenPackClient:
    """
    Client for interacting with the RavenPack Data API to fetch news items.
    """
    def __init__(self):
        self.api_key = config.RAVENPACK_API_KEY
        self.base_url = config.RAVENPACK_BASE_URL
        self.headers = {
            "API-Key": self.api_key, 
            "Content-Type": "application/json"
        }
        
    def fetch_news_iter(self, rp_entity_id: str, start_date: datetime, end_date: datetime, job_id: int, min_relevance: int = 80, log_type: str = "fetch_ravenpack_api"):
        """
        Generates news data in chunks (per API page) for a single RP_ENTITY_ID.
        Returns a generator of DataFrames.
        """
        endpoint = config.RAVENPACK_ENDPOINT or "/json"
        url = f"{self.base_url.rstrip('/')}{endpoint}"
        
        params = {
            "start_date": start_date.strftime("%Y-%m-%d %H:%M:%S"),
            "end_date": end_date.strftime("%Y-%m-%d %H:%M:%S"),
            "product": "rpa",
            "product_version": "1.0",
            "filters": {
                "rp_entity_id": {"$in": [rp_entity_id]}
            }
        }
        
        next_page_token = None
        while True:
            if next_page_token:
                params["token"] = next_page_token
                
            response_obj = self._make_request(url, params, job_id, log_type=log_type)
            
            if response_obj is None:
                break
                
            if response_obj.status_code == 400:
                error_data = response_obj.json()
                error_reason = "".join([e.get('reason', '') for e in error_data.get('errors', [])])
                if "exceeds 10000" in error_reason.lower():
                    raise ValueError(f"exceeds 10000 records")
                break
            
            if response_obj.status_code != 200:
                break
                
            data = response_obj.json()
            records = data.get("records", [])
            if not records:
                break
                
            df = pd.DataFrame(records)
            
            # Enforce minimum relevance requirement internally
            relevance_col = next((col for col in df.columns if 'RELEVANCE' in col.upper()), None)
            if relevance_col:
                df = df[df[relevance_col] >= min_relevance]
                
            if not df.empty:
                yield df
            
            next_page_token = data.get("next_page")
            if not next_page_token:
                break

    def fetch_news_adaptive(self, rp_entity_id: str, start_date: datetime, end_date: datetime, job_id: int, min_relevance: int = 80, log_type: str = "fetch_ravenpack_adaptive") -> pd.DataFrame:
        """
        Fetches news data using an adaptive time-window strategy to handle the 10,000 record limit.
        Tries windows from 3 months down to 1 day.
        """
        windows = [
            relativedelta(months=3),
            relativedelta(months=1),
            relativedelta(weeks=1),
            relativedelta(days=1)
        ]
        
        all_dfs = []
        current_start = start_date
        
        while current_start < end_date:
            success = False
            for window in windows:
                chunk_end = min(current_start + window, end_date)
                log_to_db(job_id, log_type, log_from="fetch_ravenpack.py", log_title="Adaptive Fetch", log_message=f"Trying adaptive fetch window: {current_start.date()} to {chunk_end.date()}", function_name="fetch_news_adaptive", class_name="RavenPackClient")
                
                try:
                    # Directly consumption of iterator! If it works, it works.
                    # No more dry-run dry requests. 
                    chunk_dfs = list(self.fetch_news_iter(rp_entity_id, current_start, chunk_end, job_id, min_relevance, log_type=log_type))
                    
                    if chunk_dfs:
                        all_dfs.extend(chunk_dfs)
                    
                    current_start = chunk_end
                    success = True
                    break # Move to next chunk from the start of windows list
                    
                except ValueError as ve:
                    if "exceeds 10000" in str(ve):
                        log_to_db(job_id, log_type, log_from="fetch_ravenpack.py", log_title="Adaptive Fetch Window Error", log_message=f"Window {window} returned > 10,000 records. Reducing window size...", log_status=False, function_name="fetch_news_adaptive", class_name="RavenPackClient")
                        continue # Try smaller window
                    else:
                        raise # Propagate unexpected ValueErrors
                
                except Exception as e:
                    log_to_db(job_id, log_type, log_from="fetch_ravenpack.py", log_title="Unexpected API Error", log_message=f"Unrecoverable error fetching {rp_entity_id} with window {window}: {e}", log_status=False, function_name="fetch_news_adaptive", class_name="RavenPackClient")
                    break # Critical failure
            
            if not success:
                if current_start < end_date:
                    log_to_db(job_id, log_type, log_from="fetch_ravenpack.py", log_title="Adaptive Fetch Failed", log_message=f"Failed to fetch data for {rp_entity_id} starting at {current_start} even with 1-day window.", log_status=False, function_name="fetch_news_adaptive", class_name="RavenPackClient")
                    raise RuntimeError(f"Adaptive fetch failed for {rp_entity_id} at {current_start}")
                break

        if not all_dfs:
            return pd.DataFrame()
            
        return pd.concat(all_dfs, ignore_index=True)

    def _make_request(self, url: str, params: Dict[str, Any], job_id: int, max_retries: int = 3, log_type: str = "fetch_ravenpack_api") -> Optional[requests.Response]:
        """
        Handles requests with Rate Limits and Retries via exponential backoff pattern.
        Returns the requests.Response object or None on connection failure.
        """
        for attempt in range(max_retries):
            try:
                # RavenPack JSON datasets accept POST requests with JSON encoded 
                
                token_info = f"(Token: {params.get('token')})" if params.get('token') else "(Initial Page)"
                
                log_to_db(job_id, log_type, log_from="fetch_ravenpack.py",
                log_title="RavenPack API Request", 
                log_message=f"Fetching data {token_info} for {url}. Params: {params}",
                log_status=True, function_name="_make_request", class_name="RavenPackClient")
                
                response = requests.post(url, headers=self.headers, json=params, timeout=30)
                
                if response.status_code == 200:
                    records_count = len(response.json().get('records', []))
                    log_to_db(job_id, log_type, log_from="fetch_ravenpack.py",
                    log_title="RavenPack API Response", 
                    log_message=f"Successfully fetched {records_count} records {token_info} from {url}",
                    log_status=True, function_name="_make_request", class_name="RavenPackClient")
                    return response
                    
                # Rate limit encountered
                elif response.status_code == 429: 
                    log_to_db(job_id, log_type, log_from="fetch_ravenpack.py", log_title="RavenPack API Response", log_message=f"Rate limited (429). Retrying after 5 seconds... (Attempt {attempt+1}/{max_retries})", log_status=False, function_name="_make_request", class_name="RavenPackClient")
                    time.sleep(5)
                    
                # Server side errors
                elif response.status_code >= 500: 
                    log_to_db(job_id, log_type, log_from="fetch_ravenpack.py", log_title="RavenPack API Response", log_message=f"Server error {response.status_code}. Retrying... (Attempt {attempt+1}/{max_retries})", log_status=False, function_name="_make_request", class_name="RavenPackClient")
                    time.sleep(5)
                    
                else:
                    log_to_db(job_id, log_type, log_from="fetch_ravenpack.py", log_title="RavenPack API Response", log_message=f"Error {response.status_code}. (Attempt {attempt+1}/{max_retries})", log_status=False, function_name="_make_request", class_name="RavenPackClient")
                    # Return the response for status like 400 so caller can check error reasons
                    return response
            except requests.exceptions.RequestException as e:
                log_to_db(job_id, log_type, log_from="fetch_ravenpack.py", log_title="RavenPack API Response", log_message=f"Request connection failed: {e}", log_status=False, function_name="_make_request", class_name="RavenPackClient")
                time.sleep(5)
                
        return None

    def _fetch_dataset_chunk(self, dataset_id: str, start_date: datetime, end_date: datetime, job_id: int) -> Optional[List[Dict[str, Any]]]:
        url = f"{self.base_url.rstrip('/')}/json/{dataset_id}"
        params = {
            "product": "rpa",
            "product_version": "1.0",
        }
        if start_date:
            params["start_date"] = start_date.strftime("%Y-%m-%d %H:%M:%S")
        if end_date:
            params["end_date"] = end_date.strftime("%Y-%m-%d %H:%M:%S")
            
        all_records = []
        next_page_token = None
        
        while True:
            if next_page_token:
                params["token"] = next_page_token
            
            response = self._make_request(url, params, job_id=job_id, log_type="fetch_dataset_data")
            
            if response is None:
                return None
                
            if response.status_code == 400:
                error_data = response.json()
                error_reason = "".join([e.get('reason', '') for e in error_data.get('errors', [])])
                if "exceeds 10000" in error_reason.lower():
                    raise ValueError("exceeds 10000")
                return None
                
            if response.status_code != 200:
                return None
                
            data = response.json()
            records = data.get("records", [])
            fields = data.get("fields")
            
            if records and fields and isinstance(records[0], list):
                # Convert list-of-lists to list-of-dicts using provided field names
                import pandas as pd
                df = pd.DataFrame(records, columns=fields)
                records = df.to_dict(orient='records')
                
            all_records.extend(records)
            
            next_page_token = data.get("next_page")
            if not next_page_token:
                break
                
        return all_records

    def fetch_dataset_data(self, dataset_id: str, start_date: datetime, end_date: datetime, job_id: int = 0) -> List[Dict[str, Any]]:
        """
        Fetches data from a specific RavenPack dataset using an initial full fetch, and falls back to adaptive windowing to prevent 10K limits only if needed.
        """
        # Step 1: Attempt the entire request window in one go
        try:
            records = self._fetch_dataset_chunk(dataset_id, start_date, end_date, job_id)
            if records is not None:
                return records
        except ValueError as ve:
            if "exceeds 10000" in str(ve):
                log_to_db(job_id, "fetch_dataset_data", "fetch_ravenpack.py", "Limits Exceeded", f"Dataset {dataset_id} exceeds 10,000 bounds. Falling back to adaptive chunks...", log_status=False, function_name="fetch_dataset_data", class_name="RavenPackClient")
            else:
                raise
        except Exception:
            pass # Fall back to safer chunking below

        # Step 2: Adaptive Chunking Fallback
        windows = [
            relativedelta(months=3),
            relativedelta(months=1),
            relativedelta(weeks=1),
            relativedelta(days=1)
        ]
        
        all_records = []
        current_start = start_date
        
        while current_start < end_date:
            success = False
            for window in windows:
                chunk_end = min(current_start + window, end_date)
                
                try:
                    records = self._fetch_dataset_chunk(dataset_id, current_start, chunk_end, job_id)
                    if records is not None:
                        all_records.extend(records)
                        current_start = chunk_end
                        success = True
                        break
                    else:
                        break # Unrecoverable API error, we abort
                except ValueError as ve:
                    if "exceeds 10000" in str(ve):
                        continue
                    raise
                except Exception as e:
                    break
                    
            if not success:
                if current_start < end_date:
                    log_to_db(job_id, "fetch_dataset_data", "fetch_ravenpack.py", "Adaptive Fetch Failed", f"Failed starting at {current_start}", log_status=False, function_name="fetch_dataset_data")
                break
                
        return all_records
    def list_datasets(self) -> List[Dict[str, Any]]:
        """
        Retrieves the list of available RavenPack datasets.
        """
        # Usually GET on /json or /json/datasets
        url = f"{self.base_url.rstrip('/')}/datasets"
        
        try:
            # Note: For listing datasets, it might be a GET request instead of POST
            response = requests.get(url, headers=self.headers, timeout=30)
            if response.status_code == 200:
                data = response.json()
                return data.get("datasets", [])
            else:
                logger.error(f"Failed to list datasets. Status: {response.status_code}")
                return []
        except Exception as e:
            logger.error(f"Error listing datasets: {e}")
            return []
