import os
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv()

# RavenPack API Configuration
RAVENPACK_API_KEY = os.getenv("RAVENPACK_API", "your_ravenpack_api_key_here")
RAVENPACK_BASE_URL = os.getenv("RAVENPACK_URL", "https://api.ravenpack.com/1.0")
RAVENPACK_ENDPOINT = os.getenv("RAVENPACK_ENDPOINT", "/json")

# PostgreSQL Database Configuration
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "postgres")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "postgres")

# Calculation Configuration
LAMBDA_DECAY = 0.1

# Data Management Configuration
DATA_RETENTION_DAYS = int(os.getenv("DATA_RETENTION_DAYS", "90"))
