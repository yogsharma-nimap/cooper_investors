import pandas as pd
import logging

logger = logging.getLogger(__name__)

class NewsPulseCalculator:
    """
    News Pulse unweighted and dynamically time-weighted decay math 
    for PSN, NSN arrays utilizing predefined bin arrays based on ESS scores
    """
    def __init__(self):
        # Exact Calculation constants imported from user's logic
        self.weights = [1/60, 2/60, 3/60, 4/60, 50/60]
        self.psn_bins = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
        self.nsn_bins = [0.0, -0.2, -0.4, -0.6, -0.8, -1.0]

    def calculate(self, df: pd.DataFrame, max_date=None) -> pd.DataFrame:
        if df.empty:
            logger.warning("Empty dataframe provided to NewsPulseCalculator.")
            return pd.DataFrame()

        # Schema Alignment
        if 'timestamp' in df.columns:
            df['Clean Date'] = pd.to_datetime(df['timestamp']).dt.date
        elif 'TIMESTAMP_UTC' in df.columns:
            df['Clean Date'] = pd.to_datetime(df['TIMESTAMP_UTC']).dt.date
            
        if 'ess' in df.columns:
            df['EVENT_SENTIMENT_SCORE'] = df['ess'].astype(float)
            
        if 'rp_entity_id' in df.columns:
            df['RP_ENTITY_ID'] = df['rp_entity_id']
            
        if 'sedol' in df.columns:
            df['SEDOL'] = df['sedol']
        elif 'SEDOL' not in df.columns:
            df['SEDOL'] = 'Unknown'

        if 'relevance' in df.columns:
            df = df[df['relevance'] >= 80].copy()
        else:
            df = df.copy()

        # Vectorized Binning
        ess = df['EVENT_SENTIMENT_SCORE']
        df['psn_1'] = ((ess >= 0.0) & (ess <= 0.2)).astype(int)
        df['psn_2'] = ((ess > 0.2)  & (ess <= 0.4)).astype(int)
        df['psn_3'] = ((ess > 0.4)  & (ess <= 0.6)).astype(int)
        df['psn_4'] = ((ess > 0.6)  & (ess <= 0.8)).astype(int)
        df['psn_5'] = ((ess > 0.8)  & (ess <= 1.0)).astype(int)

        df['nsn_1'] = ((ess < 0.0)  & (ess > -0.2)).astype(int)
        df['nsn_2'] = ((ess <= -0.2) & (ess >= -0.4)).astype(int)
        df['nsn_3'] = ((ess < -0.4) & (ess >= -0.6)).astype(int)
        df['nsn_4'] = ((ess < -0.6) & (ess >= -0.8)).astype(int)
        df['nsn_5'] = ((ess < -0.8) & (ess >= -1.0)).astype(int)

        # Aggregate by Stock and Date
        daily_agg = df.groupby(['RP_ENTITY_ID', 'SEDOL', 'Clean Date']).agg({
            'psn_1': 'sum', 'psn_2': 'sum', 'psn_3': 'sum', 'psn_4': 'sum', 'psn_5': 'sum',
            'nsn_1': 'sum', 'nsn_2': 'sum', 'nsn_3': 'sum', 'nsn_4': 'sum', 'nsn_5': 'sum'
        }).reset_index().sort_values(['RP_ENTITY_ID', 'SEDOL', 'Clean Date'])

        # Apply Weights
        w = self.weights
        daily_agg['psn_unweighted'] = (daily_agg['psn_1']*w[0] + daily_agg['psn_2']*w[1] + 
                                      daily_agg['psn_3']*w[2] + daily_agg['psn_4']*w[3] + daily_agg['psn_5']*w[4])
        daily_agg['nsn_unweighted'] = (daily_agg['nsn_1']*w[0] + daily_agg['nsn_2']*w[1] + 
                                      daily_agg['nsn_3']*w[2] + daily_agg['nsn_4']*w[3] + daily_agg['nsn_5']*w[4])

        # Denom & Unweighted Pulse
        denom_u = daily_agg['psn_unweighted'] + daily_agg['nsn_unweighted']
        daily_agg['News Pulse (Unweighted)'] = ((daily_agg['psn_unweighted'] - daily_agg['nsn_unweighted']) / 
                                               denom_u.replace(0, float('nan'))).fillna(0) * 100

        # Cumulative Time-Weighted logic per group
        results = []
        for (rp_id, sedol), stock_df in daily_agg.groupby(['RP_ENTITY_ID', 'SEDOL']):
            stock_df = stock_df.copy()
            n_days = len(stock_df)
            summer = n_days * (n_days + 1) / 2
            
            stock_df['day_index'] = range(1, n_days + 1)
            stock_df['daily_weight'] = stock_df['day_index'] / summer
            
            # Cumulative Weighted components
            stock_df['weighted_psn'] = stock_df['psn_unweighted'] * stock_df['daily_weight']
            stock_df['weighted_nsn'] = stock_df['nsn_unweighted'] * stock_df['daily_weight']
            
            stock_df['cum_psn_tw'] = stock_df['weighted_psn'].cumsum()
            stock_df['cum_nsn_tw'] = stock_df['weighted_nsn'].cumsum()
            
            denom_tw = stock_df['cum_psn_tw'] + stock_df['cum_nsn_tw']
            stock_df['News Pulse (TimeWeighted)'] = ((stock_df['cum_psn_tw'] - stock_df['cum_nsn_tw']) / 
                                                    denom_tw.replace(0, float('nan'))).fillna(0) * 100
            
            # Formatting to match expected output schema
            for _, row in stock_df.iterrows():
                results.append({
                    'RP_ENTITY_ID': rp_id, 'SEDOL': sedol, 'Days': int(row['day_index']),
                    'Dates': str(row['Clean Date']),
                    'PSN 1': int(row['psn_1']), 'PSN 2': int(row['psn_2']), 'PSN 3': int(row['psn_3']), 
                    'PSN 4': int(row['psn_4']), 'PSN 5': int(row['psn_5']),
                    'NSN 1': int(row['nsn_1']), 'NSN 2': int(row['nsn_2']), 'NSN 3': int(row['nsn_3']), 
                    'NSN 4': int(row['nsn_4']), 'NSN 5': int(row['nsn_5']),
                    'PSN (Unweighted)': round(float(row['psn_unweighted']), 1),
                    'NSN (Unweighted)': round(float(row['nsn_unweighted']), 1),
                    'News Pulse (Unweighted)': round(float(row['News Pulse (Unweighted)']), 2),
                    'Daily Weight': round(float(row['daily_weight'] * 100), 2),
                    'PSN (TimeWeighted)': round(float(row['cum_psn_tw']), 1),
                    'NSN (TimeWeighted)': round(float(row['cum_nsn_tw']), 1),
                    'News Pulse (TimeWeighted)': round(float(row['News Pulse (TimeWeighted)']), 2)
                })

        return pd.DataFrame(results)
