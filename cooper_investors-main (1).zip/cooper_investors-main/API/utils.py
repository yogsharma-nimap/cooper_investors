import logging
from datetime import datetime

logger = logging.getLogger(__name__)

def log_to_db(job_id: int, log_type: str, log_from: str, log_title: str, log_message: str, log_status: bool = True, function_name: str = None, class_name: str = None):
    try:
        from db import DatabaseOperation
        db_ops = DatabaseOperation()
        db_ops.log_to_db(job_id, log_type, log_from, log_title, log_message, log_status, function_name, class_name)

        logger.info(f"{datetime.now()} - {log_type} - {log_from} - {log_title} - {log_message} - {log_status} - {function_name} - {class_name}")

    except Exception as e:
        logger.error(f"Error logging to database: {e}")