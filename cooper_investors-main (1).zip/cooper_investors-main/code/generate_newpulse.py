import pandas as pd
import numpy as np

def generate_report(excel_file, output_csv):
    """
    Reads RavenPack data from Excel and generates a Daily News Pulse report
    matching the logic and columns of the 'Apple News Pulse' sheet.
    """
    # 1. Load source data (only the relevant sheet)
    print(f"Loading data from {excel_file}...")
    df = pd.read_excel(excel_file, sheet_name='Apple News Data from RavenPack')
    
    # 2. Pre-process dates
    df['Clean Date'] = pd.to_datetime(df['Clean Date']).dt.date
    df.sort_values('Clean Date', inplace=True)
    all_dates = sorted(df['Clean Date'].unique())
    n_days = len(all_dates)
    
    # Summer for Daily Weight calculation (Sum of integers from 1 to N)
    summer = n_days * (n_days + 1) / 2
    
    # 3. Define calculation constants
    weights = [1/60, 2/60, 3/60, 4/60, 50/60]
    psn_bins = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
    nsn_bins = [0.0, -0.2, -0.4, -0.6, -0.8, -1.0]
    
    results = []
    cumulative_psn_tw = 0
    cumulative_nsn_tw = 0
    
    print(f"Processing {n_days} days...")
    
    # 4. Process each day
    for i, date in enumerate(all_dates):
        day_df = df[df['Clean Date'] == date]
        ess = day_df['EVENT_SENTIMENT_SCORE']
        
        # Categorize ESS into PSN/NSN bins
        # Positive and Zero bins (PSN 1-5)
        # B1: [0, 0.2], B2: (0.2, 0.4], B3: (0.4, 0.6], ...
        psn_counts = []
        for j in range(5):
            lower, upper = psn_bins[j], psn_bins[j+1]
            if j == 0:
                count = ((ess >= lower) & (ess <= upper)).sum()
            else:
                count = ((ess > lower) & (ess <= upper)).sum()
            psn_counts.append(count)
            
        # Negative bins (NSN 1-5)
        # B1: (-0.2, 0), B2: (-0.4, -0.2], B3: (-0.6, -0.4], ...
        nsn_counts = []
        for j in range(5):
            upper, lower = nsn_bins[j], nsn_bins[j+1]
            if j == 0:
                count = ((ess > lower) & (ess < upper)).sum()
            else:
                count = ((ess >= lower) & (ess <= upper)).sum()
            nsn_counts.append(count)
            
        # Calculate Unweighted pulse metrics
        psn_unweighted = sum(c * w for c, w in zip(psn_counts, weights))
        nsn_unweighted = sum(c * w for c, w in zip(nsn_counts, weights))
        
        # Unweighted News Pulse Formula: (PSN - NSN) / (PSN + NSN)
        denom_u = psn_unweighted + nsn_unweighted
        news_pulse_unweighted = (psn_unweighted - nsn_unweighted) / denom_u if denom_u != 0 else 0
        
        # 5. Calculate TimeWeighted metrics
        day_index = i + 1
        daily_weight = day_index / summer
        
        # Cumulative additions (Time-Decay Weighted)
        cumulative_psn_tw += psn_unweighted * daily_weight
        cumulative_nsn_tw += nsn_unweighted * daily_weight
        
        # TimeWeighted News Pulse Formula: (PSN_TW - NSN_TW) / (PSN_TW + NSN_TW)
        denom_tw = cumulative_psn_tw + cumulative_nsn_tw
        news_pulse_tw = (cumulative_psn_tw - cumulative_nsn_tw) / denom_tw if denom_tw != 0 else 0
        
        results.append({
            'Days': day_index,
            'Dates': date,
            'PSN 1': psn_counts[0],
            'PSN 2': psn_counts[1],
            'PSN 3': psn_counts[2],
            'PSN 4': psn_counts[3],
            'PSN 5': psn_counts[4],
            'NSN 1': nsn_counts[0],
            'NSN 2': nsn_counts[1],
            'NSN 3': nsn_counts[2],
            'NSN 4': nsn_counts[3],
            'NSN 5': nsn_counts[4],
            'PSN (Unweighted)': psn_unweighted,
            'NSN (Unweighted)': nsn_unweighted,
            'News Pulse (Unweighted)': news_pulse_unweighted,
            'Daily Weight': daily_weight,
            'PSN (TimeWeighted)': cumulative_psn_tw,
            'NSN (TimeWeighted)': cumulative_nsn_tw,
            'News Pulse (TimeWeighted)': news_pulse_tw
        })
        
    # 6. Save results to CSV
    final_df = pd.DataFrame(results)
    final_df.to_csv(output_csv, index=False)
    print(f"Report saved to {output_csv}")

if __name__ == "__main__":
    generate_report('ravenpack_test.csv', 'ravenpack_test_pulse.csv')
