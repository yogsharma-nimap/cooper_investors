import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dotenv import load_dotenv
from sedol import RavenPackMapper

# Try importing the RavenPack API (make sure `pip install ravenpackapi` is installed in your environment)
try:
    from ravenpackapi import RPApi, Dataset
except ImportError:
    print("Warning: ravenpackapi not installed. Please run `pip install ravenpackapi`")

def fetch_raw_data_from_ravenpack(sedols, mapping_file, output_csv):
    """
    Fetches the 12-month daily raw data for a list of SEDOLs from the RavenPack API.
    It maps SEDOLs to RP_ENTITY_IDs, creates/queries a dataset, and saves to CSV.
    """
    load_dotenv()
    api_key = os.getenv('RAVENPACK_API')
    
    if not api_key:
        raise ValueError("RAVENPACK_API key is not set in the environment or .env file.")
        
    api = RPApi(api_key=api_key)
    
    # 1. Map SEDOLs to RP_ENTITY_IDs
    mapper = RavenPackMapper(mapping_file)
    rp_entity_ids = []
    rp_id_to_sedol = {}
    
    print("\nMapping SEDOLs to RP_ENTITY_IDs...")
    today_str = datetime.now().strftime('%Y-%m-%d')
    for sedol in sedols:
        rp_id = mapper.get_rp_id(sedol, target_date=today_str)
        if rp_id:
            rp_entity_ids.append(rp_id)
            rp_id_to_sedol[rp_id] = sedol
            print(f"Mapped {sedol} -> {rp_id}")
        else:
            print(f"Could not map SEDOL {sedol} to an RP_ENTITY_ID.")
            
    if not rp_entity_ids:
        print("No Valid RP_ENTITY_IDs found. Ending process.")
        return None
        
    # 2. Setup date range for 12 months
    end_date = datetime.now()
    start_date = end_date - relativedelta(months=12)
    start_date_str = start_date.strftime('%Y-%m-%d 00:00:00')
    end_date_str = end_date.strftime('%Y-%m-%d 23:59:59')
    print(f"\nFetching data from {start_date_str} to {end_date_str}...")
    
    # 3. Use RavenPack Dataset to fetch
    # We filter by rp_entity_id and relevance >= 80 as standard
    filters = {
        "rp_entity_id": {"$in": rp_entity_ids},
        "relevance": {"$gte": 80}
    }
    
    print("Creating or requesting Dataset on Ravenpack...")
    dataset = Dataset(
        name=f"NewsPulse_SEDOLs_12M_{datetime.now().strftime('%Y%m%d%H%M%S')}",
        filters=filters
    )
    
    dataset = api.create_dataset(dataset)
    
    # Depending on data size, request a datafile which operates asynchronously or synchronously
    print("Requesting datafile (this might take some time depending on dataset size)...")
    job = dataset.request_datafile(
        start_date=start_date_str, 
        end_date=end_date_str
    )
    
    # Save the output to a CSV file (This acts as the one-time raw data dump for the cloud storage)
    print(f"Saving fetched raw data to {output_csv}...")
    job.save_to_file(output_csv)
    print("Raw data download complete.\n")
    
    return rp_id_to_sedol


def calculate_stock_level_analytics(raw_csv, output_csv, rp_id_to_sedol=None):
    """
    Reads the raw RavenPack data and calculates the News Pulse for each stock/entity on a daily basis.
    Applies the Apple News Pulse calculation logic per entity.
    """
    print(f"Calculating stock-level analytics from {raw_csv}...")
    df = pd.read_csv(raw_csv)
    
    # Pre-process columns
    if 'TIMESTAMP_UTC' in df.columns and 'Clean Date' not in df.columns:
        df['Clean Date'] = pd.to_datetime(df['TIMESTAMP_UTC']).dt.date
    elif 'Clean Date' in df.columns:
        df['Clean Date'] = pd.to_datetime(df['Clean Date']).dt.date
    else:
        # Some RavenPack outputs default to just TIMESTAMP_UTC
        raise KeyError("Could not find a date column (expected 'Clean Date' or 'TIMESTAMP_UTC')")
        
    if 'ESS' in df.columns and 'EVENT_SENTIMENT_SCORE' not in df.columns:
        df['EVENT_SENTIMENT_SCORE'] = df['ESS']
        
    if 'RP_ENTITY_ID' not in df.columns:
        raise KeyError("Expected 'RP_ENTITY_ID' in raw data layout to group by stock.")
        
    # Map back SEDOLs if the dictionary was passed
    if rp_id_to_sedol:
        df['SEDOL'] = df['RP_ENTITY_ID'].map(rp_id_to_sedol)
    else:
        df['SEDOL'] = 'Unknown'
        
    # Calculation constants
    weights = [1/60, 2/60, 3/60, 4/60, 50/60]
    psn_bins = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
    nsn_bins = [0.0, -0.2, -0.4, -0.6, -0.8, -1.0]
    
    all_results = []
    
    # Group by Stock (using RP_ENTITY_ID)
    grouped = df.groupby(['RP_ENTITY_ID', 'SEDOL'])
    
    for (rp_id, sedol), stock_df in grouped:
        stock_df = stock_df.sort_values('Clean Date')
        all_dates = sorted(stock_df['Clean Date'].unique())
        n_days = len(all_dates)
        
        if n_days == 0:
            continue
            
        summer = n_days * (n_days + 1) / 2
        
        cumulative_psn_tw = 0
        cumulative_nsn_tw = 0
        
        for i, date in enumerate(all_dates):
            day_df = stock_df[stock_df['Clean Date'] == date]
            ess = day_df['EVENT_SENTIMENT_SCORE']
            
            # Positive Bins
            psn_counts = []
            for j in range(5):
                lower, upper = psn_bins[j], psn_bins[j+1]
                if j == 0:
                    count = ((ess >= lower) & (ess <= upper)).sum()
                else:
                    count = ((ess > lower) & (ess <= upper)).sum()
                psn_counts.append(count)
                
            # Negative Bins
            nsn_counts = []
            for j in range(5):
                upper, lower = nsn_bins[j], nsn_bins[j+1]
                if j == 0:
                    count = ((ess > lower) & (ess < upper)).sum()
                else:
                    count = ((ess >= lower) & (ess <= upper)).sum()
                nsn_counts.append(count)
                
            psn_unweighted = sum(c * w for c, w in zip(psn_counts, weights))
            nsn_unweighted = sum(c * w for c, w in zip(nsn_counts, weights))
            
            denom_u = psn_unweighted + nsn_unweighted
            news_pulse_unweighted = (psn_unweighted - nsn_unweighted) / denom_u if denom_u != 0 else 0
            
            # Time Weighted metrics
            day_index = i + 1
            daily_weight = day_index / summer
            
            cumulative_psn_tw += psn_unweighted * daily_weight
            cumulative_nsn_tw += nsn_unweighted * daily_weight
            
            denom_tw = cumulative_psn_tw + cumulative_nsn_tw
            news_pulse_tw = (cumulative_psn_tw - cumulative_nsn_tw) / denom_tw if denom_tw != 0 else 0
            
            all_results.append({
                'RP_ENTITY_ID': rp_id,
                'SEDOL': sedol,
                'Days': day_index,
                'Dates': date,
                'PSN (Unweighted)': psn_unweighted,
                'NSN (Unweighted)': nsn_unweighted,
                'News Pulse (Unweighted)': news_pulse_unweighted,
                'Daily Weight': daily_weight,
                'PSN (TimeWeighted)': cumulative_psn_tw,
                'NSN (TimeWeighted)': cumulative_nsn_tw,
                'News Pulse (TimeWeighted)': news_pulse_tw
            })

    final_df = pd.DataFrame(all_results)
    final_df.to_csv(output_csv, index=False)
    print(f"Stock-level analytics saved to {output_csv}")

if __name__ == "__main__":
    # The SEDOLs mentioned by the user
    test_sedols = [
        "688910",
        "647295",
        "659704",
        "BW4F6F",
        "BZ0RDZ",
        "664048",
        "680448"
    ]
    
    mapping_file = '../file/RPA_entity-mapping-1.0_2026-04-01.csv'
    raw_output_csv = '../file/raw_sedol_12m.csv'
    analytics_output_csv = '../file/sedols_newspulse_12m.csv'
    
    print("STARTING PIPELINE...")
    try:
        # Step 1: Fetch raw data
        rp_to_sedol_map = fetch_raw_data_from_ravenpack(
            sedols=test_sedols, 
            mapping_file=mapping_file, 
            output_csv=raw_output_csv
        )
        
        # Step 2: Calculate daily news pulse per stock
        if rp_to_sedol_map and os.path.exists(raw_output_csv):
            calculate_stock_level_analytics(
                raw_csv=raw_output_csv, 
                output_csv=analytics_output_csv,
                rp_id_to_sedol=rp_to_sedol_map
            )
            
    except Exception as e:
        print(f"Pipeline error: {e}")
