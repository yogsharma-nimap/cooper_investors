import pandas as pd
from datetime import datetime

class RavenPackMapper:
    def __init__(self, mapping_file_path: str):
        """
        Initializes with the path to the RavenPack Entity Reference mapping file.
        Expects columns: RP_ENTITY_ID, ENTITY_TYPE, DATA_TYPE, DATA_VALUE, RANGE_START, RANGE_END
        """
        print(f"Loading mapping from {mapping_file_path}...")
        self.mapping_df = pd.read_csv(mapping_file_path, encoding='latin1', low_memory=False)
        
        self.mapping_df['RANGE_START'] = pd.to_datetime(self.mapping_df['RANGE_START'])
        self.mapping_df['RANGE_END'] = pd.to_datetime(self.mapping_df['RANGE_END']).fillna(pd.Timestamp('2099-12-31'))
        self.mapping_df['DATA_VALUE'] = self.mapping_df['DATA_VALUE'].astype(str)
        print("Mapping loaded successfully.")
        
    def get_rp_id(self, sedol: str, target_date: str = None) -> str:
        """
        Retrieves the RP_ENTITY_ID for a given SEDOL at a specific point in time.
        Handles both 6 and 7 character SEDOLs by performing a prefix search if necessary.
        """
        query_date = pd.to_datetime(target_date) if target_date else pd.Timestamp.now()
        
        # 1. Try exact match
        matched = self.mapping_df[
            (self.mapping_df['DATA_TYPE'] == 'SEDOL') & 
            (self.mapping_df['DATA_VALUE'] == sedol) & 
            (self.mapping_df['RANGE_START'] <= query_date) & 
            (self.mapping_df['RANGE_END'] >= query_date)
        ]
        
        if not matched.empty:
            return matched['RP_ENTITY_ID'].iloc[0]
            
        # 2. Try prefix match (for 6-character fragments)
        if len(sedol) == 6:
            matched = self.mapping_df[
                (self.mapping_df['DATA_TYPE'] == 'SEDOL') & 
                (self.mapping_df['DATA_VALUE'].str.startswith(sedol)) & 
                (self.mapping_df['RANGE_START'] <= query_date) & 
                (self.mapping_df['RANGE_END'] >= query_date)
            ]
            if not matched.empty:
                # If multiple matches (rare for SEDOL+date), return the first one
                return matched['RP_ENTITY_ID'].iloc[0]
        
        return None

if __name__ == "__main__":
    # Test routine
    mapping_file = 'RPA_entity-mapping-1.0_2026-04-01.csv'
    mapper = RavenPackMapper(mapping_file)
    
    test_sedols = [
        "688910",
        "647295",
        "659704",
        "BW4F6F",
        "BZ0RDZ",
        "664048",
        "680448"
    ]
    
    query_date = '2026-04-01'
    
    print("\n--- SEDOL to RP_ENTITY_ID Mappings ---")
    results = {}
    for sedol in test_sedols:
        rp_id = mapper.get_rp_id(sedol, target_date=query_date)
        results[sedol] = rp_id
        print(f"SEDOL: {sedol} => RP_ENTITY_ID: {rp_id}")