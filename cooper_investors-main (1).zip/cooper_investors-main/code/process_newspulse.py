import pandas as pd
import numpy as np

def calculate_news_pulse(input_file, output_file):
    df_full = pd.read_excel(input_file, sheet_name='Apple News Pulse', header=None)
    
    # Data starts from row 6 (index 5) and goes to row 95 (index 94)
    df_data = df_full.iloc[5:95].copy()
    
    clean_df = pd.DataFrame()
    clean_df['Days'] = pd.to_numeric(df_data[0], errors='coerce').fillna(0)
    clean_df['Dates'] = df_data[1]
    
    for i in range(1, 6):
        col_idx = 1 + i # Index 2, 3, 4, 5, 6
        clean_df[f'PSN{i}'] = pd.to_numeric(df_data[col_idx], errors='coerce').fillna(0)
        
    for i in range(1, 6):
        col_idx = 6 + i # Index 7, 8, 9, 10, 11
        clean_df[f'NSN{i}'] = pd.to_numeric(df_data[col_idx], errors='coerce').fillna(0)
    
    weights = np.array([1/60, 2/60, 3/60, 4/60, 50/60])
    
    psn_counts = clean_df[[f'PSN{i}' for i in range(1, 6)]].values
    nsn_counts = clean_df[[f'NSN{i}' for i in range(1, 6)]].values
    
    psn_unweighted = psn_counts @ weights
    nsn_unweighted = nsn_counts @ weights
    
    # 2. News Pulse Unweighted
    # (P-N)/(P+N)
    denom_unweighted = (psn_unweighted + nsn_unweighted)
    news_pulse_unweighted = np.where(denom_unweighted != 0, (psn_unweighted - nsn_unweighted) / denom_unweighted, 0)
    
    # 3. Time Weighted Components
    total_days_sum = clean_df['Days'].sum()
    daily_weights = clean_df['Days'] / total_days_sum
    
    # PSN and NSN TimeWeighted (Weighted Sums)
    psn_weighted_sum = (daily_weights * psn_unweighted).cumsum()
    nsn_weighted_sum = (daily_weights * nsn_unweighted).cumsum()
    
    # 4. News Pulse TimeWeighted
    denom_timeweighted = (psn_weighted_sum + nsn_weighted_sum)
    news_pulse_time_weighted = np.where(denom_timeweighted != 0, (psn_weighted_sum - nsn_weighted_sum) / denom_timeweighted, 0)
    
    # 1. PSN and NSN unweighted/Weighted rounded to 1 digit
    clean_df['PSN_Unweighted'] = np.round(psn_unweighted, 1)
    clean_df['NSN_Unweighted'] = np.round(nsn_unweighted, 1)
    
    # News Pulse Unweighted to % (already requested before)
    clean_df['News_Pulse_Unweighted'] = (news_pulse_unweighted * 100).round(2).astype(str) + '%'
    
    # 2. Daily weight to f"value * 100"%
    clean_df['Daily_Weight'] = (daily_weights * 100).round(2).astype(str) + '%'
    
    clean_df['PSN_Weighted_Sum'] = np.round(psn_weighted_sum, 1)
    clean_df['NSN_Weighted_Sum'] = np.round(nsn_weighted_sum, 1)
    
    # News Pulse TimeWeighted to %
    clean_df['News_Pulse_TimeWeighted'] = (news_pulse_time_weighted * 100).round(2).astype(str) + '%'
    
    # Export to CSV
    clean_df.to_csv(output_file, index=False)
    print(f"File saved to {output_file}")
    
    print("\nVerification (Last Row):")
    print(clean_df.iloc[-1][['PSN_Unweighted', 'NSN_Unweighted', 'News_Pulse_Unweighted', 'Daily_Weight', 'News_Pulse_TimeWeighted']])

if __name__ == "__main__":
    calculate_news_pulse("Apple_NewsPulse.xlsx", "final_calculated_data.csv")
